
import React, { useState, useCallback } from 'react';
import { visualizeStain } from '../services/geminiService';
import { WOOD_TYPES, STAIN_COLORS } from '../constants';
import Card, { CardContent, CardHeader, CardTitle } from './Card';
import Spinner from './Spinner';

const StainVisualizer: React.FC = () => {
    const [woodType, setWoodType] = useState<string>(WOOD_TYPES[0]);
    const [stainColor, setStainColor] = useState<string>(STAIN_COLORS[0]);
    const [generatedImage, setGeneratedImage] = useState<string | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    const handleVisualize = useCallback(async (isInitialLoad = false) => {
        if (!isInitialLoad) {
            setLoading(true);
            setError(null);
            setGeneratedImage(null);
        }
        try {
            const imageB64 = await visualizeStain(woodType, stainColor);
            setGeneratedImage(`data:image/jpeg;base64,${imageB64}`);
        } catch (err) {
            setError('Failed to generate image. Please try a different combination.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, [woodType, stainColor]);
    
    // eslint-disable-next-line react-hooks/exhaustive-deps
    React.useEffect(() => {
        handleVisualize(true);
    }, []);

    return (
        <div className="max-w-4xl mx-auto">
            <Card>
                <CardHeader>
                    <CardTitle>Stain Visualizer</CardTitle>
                    <p className="text-stone-600 mt-1">See how different stains look on various wood types.</p>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="woodType" className="block text-sm font-medium text-stone-700">Wood Type</label>
                            <select
                                id="woodType"
                                value={woodType}
                                onChange={(e) => setWoodType(e.target.value)}
                                className="mt-1 block w-full border border-stone-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-amber-500 focus:border-amber-500"
                            >
                                {WOOD_TYPES.map(w => <option key={w} value={w}>{w}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="stainColor" className="block text-sm font-medium text-stone-700">Stain Color</label>
                             <select
                                id="stainColor"
                                value={stainColor}
                                onChange={(e) => setStainColor(e.target.value)}
                                className="mt-1 block w-full border border-stone-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-amber-500 focus:border-amber-500"
                            >
                                {STAIN_COLORS.map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                        </div>
                         <button
                            onClick={() => handleVisualize()}
                            disabled={loading}
                            className="w-full px-8 py-2 bg-amber-700 text-white font-semibold rounded-lg shadow-md hover:bg-amber-800 disabled:bg-stone-400 transition-colors"
                        >
                            {loading ? 'Generating...' : 'Visualize'}
                        </button>
                    </div>
                    <div className="flex items-center justify-center bg-stone-100 rounded-lg aspect-square">
                        {loading && <Spinner text="Staining wood..." />}
                        {error && <div className="text-center text-red-600 p-4">{error}</div>}
                        {generatedImage && !loading && (
                            <img src={generatedImage} alt={`A block of ${woodType} stained with ${stainColor}`} className="w-full h-full object-cover rounded-lg shadow-inner animate-fade-in" />
                        )}
                        {!loading && !generatedImage && !error && <div className="text-stone-500">Image will appear here</div>}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

export default StainVisualizer;
