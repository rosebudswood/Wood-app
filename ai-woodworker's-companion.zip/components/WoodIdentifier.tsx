
import React, { useState, useCallback } from 'react';
import { identifyWood } from '../services/geminiService';
import { WoodIdentification } from '../types';
import Card, { CardContent, CardHeader, CardTitle } from './Card';
import Spinner from './Spinner';
import { CameraIcon } from './icons/CameraIcon';
import CameraCapture from './CameraCapture';

const WoodIdentifier: React.FC = () => {
    const [image, setImage] = useState<string | null>(null);
    const [result, setResult] = useState<WoodIdentification | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [showCamera, setShowCamera] = useState<boolean>(false);
    
    const resetState = () => {
        setResult(null); 
        setError(null);
        setLoading(false);
    }

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onloadend = () => {
                setImage(reader.result as string);
                resetState();
            };
            reader.readAsDataURL(file);
        }
    };

    const handleCameraCapture = (imageDataUrl: string) => {
        setImage(imageDataUrl);
        resetState();
        setShowCamera(false);
    };

    const handleIdentification = useCallback(async () => {
        if (!image) {
            setError("Please upload or capture an image first.");
            return;
        }
        setLoading(true);
        setError(null);
        setResult(null);
        try {
            const base64Data = image.split(',')[1];
            const mimeType = image.split(';')[0].split(':')[1];
            const identificationResult = await identifyWood(base64Data, mimeType);
            setResult(identificationResult);
        } catch (err) {
            setError("Failed to identify wood. The model may be unable to process this image.");
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, [image]);
    
    const getConfidenceColor = (confidence: string) => {
        switch (confidence?.toLowerCase()) {
            case 'high':
                return 'bg-green-100 text-green-800';
            case 'medium':
                return 'bg-yellow-100 text-yellow-800';
            case 'low':
                return 'bg-red-100 text-red-800';
            default:
                return 'bg-stone-100 text-stone-800';
        }
    };

    if (showCamera) {
        return <CameraCapture onCapture={handleCameraCapture} onCancel={() => setShowCamera(false)} />;
    }

    return (
        <div>
            <Card>
                <CardHeader>
                    <CardTitle>Wood Identifier</CardTitle>
                    <p className="text-stone-600 mt-1">Upload or capture an image of wood grain to get it identified by AI.</p>
                </CardHeader>
                <CardContent>
                     <div className="flex flex-col items-center">
                        <div className="w-full max-w-sm">
                            <label htmlFor="file-upload" className="w-full cursor-pointer bg-amber-100 text-amber-800 font-semibold rounded-full py-2 px-4 hover:bg-amber-200 transition-colors text-center block">
                                Upload an Image
                            </label>
                            <input id="file-upload" type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
                            <div className="my-2 text-center text-stone-500">OR</div>
                            <button
                                onClick={() => setShowCamera(true)}
                                className="w-full flex items-center justify-center gap-2 cursor-pointer bg-stone-200 text-stone-800 font-semibold rounded-full py-2 px-4 hover:bg-stone-300 transition-colors"
                            >
                                <CameraIcon className="h-5 w-5" />
                                Use Camera
                            </button>
                        </div>

                        {image && (
                            <div className="mt-6 border-2 border-dashed border-stone-300 rounded-lg p-2 bg-stone-50">
                                <img src={image} alt="Wood preview" className="max-h-64 rounded-md" />
                            </div>
                        )}
                        <button
                            onClick={handleIdentification}
                            disabled={!image || loading}
                            className="mt-6 px-6 py-2 bg-amber-700 text-white font-semibold rounded-lg shadow-md hover:bg-amber-800 disabled:bg-stone-400 disabled:cursor-not-allowed transition-colors"
                        >
                            {loading ? 'Identifying...' : 'Identify Wood'}
                        </button>
                    </div>
                </CardContent>
            </Card>

            {loading && <div className="flex justify-center mt-8"><Spinner text="Examining grain..." /></div>}
            {error && <div className="mt-6 text-center text-red-600 bg-red-100 p-4 rounded-md">{error}</div>}
            
            {result && (
                <Card className="mt-6 animate-fade-in">
                    <CardHeader>
                         <div className="flex justify-between items-start">
                             <CardTitle>Identification Result: <span className="text-amber-800">{result.wood_species}</span></CardTitle>
                             <span className={`px-3 py-1 text-xs font-semibold rounded-full ${getConfidenceColor(result.confidence)}`}>
                                 {result.confidence} Confidence
                             </span>
                         </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        {result.confidence_reasoning && (
                             <div className="p-3 bg-stone-50 rounded-lg">
                                 <p className="text-sm text-stone-600"><span className="font-semibold">Reasoning:</span> {result.confidence_reasoning}</p>
                             </div>
                        )}
                        <div>
                            <h4 className="font-semibold text-stone-700">Characteristics</h4>
                            <p className="text-stone-600">{result.characteristics}</p>
                        </div>
                         <div>
                            <h4 className="font-semibold text-stone-700">Typical Uses</h4>
                            <p className="text-stone-600">{result.typical_uses}</p>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
};

export default WoodIdentifier;
