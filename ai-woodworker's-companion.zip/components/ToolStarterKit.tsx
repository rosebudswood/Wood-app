
import React, { useState, useCallback } from 'react';
import { getToolRecommendations } from '../services/geminiService';
import { ToolRecommendations, Budget, Tool, Currency } from '../types';
import { WOODWORKING_INTERESTS, CURRENCIES } from '../constants';
import Card, { CardContent, CardHeader, CardTitle, CardDescription } from './Card';
import Spinner from './Spinner';
import { HammerIcon } from './icons/HammerIcon';

const ToolList: React.FC<{title: string, tools: Tool[]}> = ({ title, tools }) => {
    if (tools.length === 0) return null;

    return (
        <Card>
            <CardHeader>
                <CardTitle>{title}</CardTitle>
            </CardHeader>
            <CardContent>
                <ul className="space-y-4">
                    {tools.map((tool, index) => (
                        <li key={index} className="flex items-start">
                            <HammerIcon className="h-5 w-5 text-amber-700 mt-1 mr-3 flex-shrink-0" />
                            <div>
                                <p className="font-semibold text-stone-800">{tool.name}</p>
                                <p className="text-stone-600 text-sm">{tool.reason}</p>
                            </div>
                        </li>
                    ))}
                </ul>
            </CardContent>
        </Card>
    );
}

const ToolStarterKit: React.FC = () => {
    const [budget, setBudget] = useState<Budget>(Budget.Budget);
    const [interest, setInterest] = useState<string>(WOODWORKING_INTERESTS[0]);
    const [currency, setCurrency] = useState<Currency>(Currency.USD);
    const [recommendations, setRecommendations] = useState<ToolRecommendations | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const handleGetRecommendations = useCallback(async () => {
        setLoading(true);
        setError(null);
        setRecommendations(null);
        try {
            const result = await getToolRecommendations(budget, interest, currency);
            setRecommendations(result);
        } catch (err) {
            setError('Failed to get tool recommendations. Please try again.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, [budget, interest, currency]);

    return (
        <div className="max-w-4xl mx-auto">
            <Card className="mb-6">
                <CardHeader>
                    <CardTitle>Tool Starter Kit</CardTitle>
                    <CardDescription>Get personalized tool recommendations for your budget and interests.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-medium text-stone-700 mb-2">Select your budget:</label>
                            <div className="flex flex-wrap gap-2">
                                {Object.values(Budget).map((level) => (
                                    <button
                                        key={level}
                                        onClick={() => setBudget(level)}
                                        className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                                            budget === level
                                                ? 'bg-amber-700 text-white shadow'
                                                : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
                                        }`}
                                    >
                                        {level}
                                    </button>
                                ))}
                            </div>
                        </div>
                        <div>
                            <label htmlFor="currency" className="block text-sm font-medium text-stone-700">Currency:</label>
                            <select
                                id="currency"
                                value={currency}
                                onChange={(e) => setCurrency(e.target.value as Currency)}
                                className="mt-1 block w-full border border-stone-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-amber-500 focus:border-amber-500"
                            >
                                {CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                        </div>
                    </div>
                    <div>
                        <label htmlFor="interest" className="block text-sm font-medium text-stone-700">Primary Interest:</label>
                        <select
                            id="interest"
                            value={interest}
                            onChange={(e) => setInterest(e.target.value)}
                            className="mt-1 block w-full border border-stone-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-amber-500 focus:border-amber-500"
                        >
                            {WOODWORKING_INTERESTS.map(i => <option key={i} value={i}>{i}</option>)}
                        </select>
                    </div>
                    <div className="text-center pt-2">
                        <button
                            onClick={handleGetRecommendations}
                            disabled={loading}
                            className="w-full sm:w-auto px-8 py-3 bg-amber-700 text-white font-semibold rounded-lg shadow-md hover:bg-amber-800 disabled:bg-stone-400 transition-all duration-200"
                        >
                            {loading ? 'Thinking...' : 'Get Recommendations'}
                        </button>
                    </div>
                </CardContent>
            </Card>

            {loading && <div className="flex justify-center mt-8"><Spinner text="Building your toolkit..." /></div>}
            {error && <div className="mt-6 text-center text-red-600 bg-red-100 p-4 rounded-md">{error}</div>}

            {recommendations && (
                <div className="space-y-6 animate-fade-in">
                    <Card className="bg-amber-50 border-amber-200 border">
                        <CardHeader>
                            <CardTitle>Recommendation Summary</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-stone-700">{recommendations.summary}</p>
                        </CardContent>
                    </Card>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                       <ToolList title="Recommended Hand Tools" tools={recommendations.handTools} />
                       <ToolList title="Recommended Power Tools" tools={recommendations.powerTools} />
                    </div>
                </div>
            )}
        </div>
    );
};

export default ToolStarterKit;
