
import React, { useState, useCallback } from 'react';
import { getProjectIdeas } from '../services/geminiService';
import { ProjectIdea, Difficulty } from '../types';
import Card, { CardContent, CardHeader, CardTitle, CardDescription } from './Card';
import Spinner from './Spinner';
import SkeletonCard from './SkeletonCard';

const ProjectIdeas: React.FC = () => {
    const [ideas, setIdeas] = useState<ProjectIdea[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty>(Difficulty.Beginner);

    const fetchIdeas = useCallback(async (difficulty: Difficulty) => {
        setLoading(true);
        setError(null);
        setIdeas([]);
        try {
            const result = await getProjectIdeas(difficulty);
            setIdeas(result);
        } catch (err) {
            setError('Failed to fetch project ideas. Please check your API key and try again.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, []);

    const handleDifficultyChange = (difficulty: Difficulty) => {
        setSelectedDifficulty(difficulty);
        fetchIdeas(difficulty);
    };
    
    // eslint-disable-next-line react-hooks/exhaustive-deps
    React.useEffect(() => {
        fetchIdeas(selectedDifficulty);
    }, []);

    return (
        <div>
            <div className="mb-6 bg-white p-4 rounded-lg shadow">
                <h2 className="text-2xl font-bold text-stone-800">Project Ideas</h2>
                <p className="text-stone-600 mt-1">Select a difficulty level to get AI-powered project ideas.</p>
                <div className="mt-4 flex flex-wrap gap-2">
                    {Object.values(Difficulty).map((level) => (
                        <button
                            key={level}
                            onClick={() => handleDifficultyChange(level)}
                            className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                                selectedDifficulty === level
                                    ? 'bg-amber-700 text-white shadow'
                                    : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
                            }`}
                        >
                            {level}
                        </button>
                    ))}
                </div>
            </div>

            {loading && (
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {Array.from({ length: 3 }).map((_, index) => <SkeletonCard key={index} />)}
                </div>
            )}
            {error && <div className="text-center text-red-600 bg-red-100 p-4 rounded-md">{error}</div>}
            
            {!loading && !error && (
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
                    {ideas.map((idea, index) => (
                        <Card key={index}>
                            <CardHeader>
                                <CardTitle>{idea.name}</CardTitle>
                                <CardDescription>{idea.description}</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <div>
                                    <h4 className="font-semibold text-stone-700">Tools Required:</h4>
                                    <ul className="list-disc list-inside text-stone-600 text-sm mt-1">
                                        {idea.tools.map((tool, i) => <li key={i}>{tool}</li>)}
                                    </ul>
                                </div>
                                <div className="mt-4">
                                    <h4 className="font-semibold text-stone-700">Materials:</h4>
                                    <ul className="list-disc list-inside text-stone-600 text-sm mt-1">
                                        {idea.materials.map((material, i) => <li key={i}>{material}</li>)}
                                    </ul>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
};

export default ProjectIdeas;
