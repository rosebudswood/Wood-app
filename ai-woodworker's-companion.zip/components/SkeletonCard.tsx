
import React from 'react';
import Card, { CardContent, CardHeader } from './Card';

interface SkeletonCardProps {
    hasImage?: boolean;
}

const SkeletonCard: React.FC<SkeletonCardProps> = ({ hasImage = false }) => {
    return (
        <Card className="animate-pulse">
            <CardHeader>
                <div className="h-6 bg-stone-200 rounded w-3/4"></div>
                <div className="mt-2 h-4 bg-stone-200 rounded w-full"></div>
            </CardHeader>
            <CardContent>
                <div className={`space-y-4 ${hasImage ? 'grid grid-cols-3 gap-4' : ''}`}>
                    <div className={hasImage ? 'col-span-2 space-y-3' : 'space-y-3'}>
                        <div className="h-4 bg-stone-200 rounded w-5/6"></div>
                        <div className="h-4 bg-stone-200 rounded"></div>
                        <div className="mt-4 h-4 bg-stone-200 rounded w-1/2"></div>
                        <div className="h-4 bg-stone-200 rounded w-5/6"></div>
                    </div>
                    {hasImage && (
                        <div className="h-24 bg-stone-200 rounded-lg"></div>
                    )}
                </div>
            </CardContent>
        </Card>
    );
};

export default SkeletonCard;
