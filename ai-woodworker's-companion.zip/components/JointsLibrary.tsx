
import React, { useState, useEffect } from 'react';
import { getJoints } from '../services/geminiService';
import { Joint } from '../types';
import Card, { CardContent, CardHeader, CardTitle } from './Card';
import Spinner from './Spinner';
import SkeletonCard from './SkeletonCard';

const JointsLibrary: React.FC = () => {
    const [joints, setJoints] = useState<Joint[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchJoints = async () => {
            setLoading(true);
            setError(null);
            try {
                const result = await getJoints();
                setJoints(result);
            } catch (err) {
                setError('Failed to load the joints library. Please try again later.');
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchJoints();
    }, []);

    const getStrengthColor = (strength: string) => {
        switch (strength.toLowerCase()) {
            case 'strong':
                return 'bg-green-100 text-green-800';
            case 'moderate':
                return 'bg-yellow-100 text-yellow-800';
            case 'weak':
                return 'bg-red-100 text-red-800';
            default:
                return 'bg-stone-100 text-stone-800';
        }
    };

    return (
        <div>
            <div className="mb-6 text-center">
                <h2 className="text-3xl font-bold text-stone-800">Woodworking Joints Library</h2>
                <p className="text-stone-600 mt-1">An AI-generated guide to common woodworking joints, complete with diagrams.</p>
            </div>
            
            {loading && (
                <div className="space-y-6">
                    {Array.from({ length: 4 }).map((_, index) => <SkeletonCard key={index} hasImage={true} />)}
                </div>
            )}
            {error && <div className="text-center text-red-600 bg-red-100 p-4 rounded-md">{error}</div>}

            {!loading && !error && (
                <div className="space-y-6 animate-fade-in">
                    {joints.map((joint, index) => (
                        <Card key={index}>
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <CardTitle>{joint.name}</CardTitle>
                                    <span className={`px-3 py-1 text-xs font-semibold rounded-full ${getStrengthColor(joint.strength)}`}>
                                        {joint.strength}
                                    </span>
                                </div>
                            </CardHeader>
                            <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="md:col-span-2 space-y-4">
                                    <div>
                                        <h4 className="font-semibold text-stone-700">Description:</h4>
                                        <p className="text-stone-600">{joint.description}</p>
                                    </div>
                                    <div>
                                        <h4 className="font-semibold text-stone-700">Common Uses:</h4>
                                        <p className="text-stone-600">{joint.uses}</p>
                                    </div>
                                </div>
                                <div className="flex items-center justify-center bg-stone-50 p-4 rounded-lg border border-stone-200">
                                     <div 
                                        className="w-32 h-32 text-stone-700"
                                        dangerouslySetInnerHTML={{ __html: joint.svg_diagram }}
                                    />
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
};

export default JointsLibrary;
