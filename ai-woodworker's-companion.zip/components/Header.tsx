
import React from 'react';
import { Tab } from '../types';
import { WoodLogIcon } from './icons/WoodLogIcon';

interface HeaderProps {
    tabs: Tab[];
    activeTab: string;
    setActiveTab: (id: string) => void;
}

const Header: React.FC<HeaderProps> = ({ tabs, activeTab, setActiveTab }) => {
    return (
        <header className="bg-white shadow-md">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-20 border-b border-stone-200">
                    <div className="flex items-center">
                        <WoodLogIcon className="h-8 w-8 text-amber-900" />
                        <h1 className="ml-3 text-2xl font-bold text-stone-800">Woodworker's Companion</h1>
                    </div>
                </div>
                <div className="md:hidden">
                    <select
                        aria-label="Selected tab"
                        className="mt-2 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm rounded-md"
                        value={activeTab}
                        onChange={(e) => setActiveTab(e.target.value)}
                    >
                        {tabs.map((tab) => (
                            <option key={tab.id} value={tab.id}>{tab.name}</option>
                        ))}
                    </select>
                </div>
                <nav className="hidden md:flex md:space-x-4 lg:space-x-8 -mb-px">
                    {tabs.map((tab) => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={`${
                                activeTab === tab.id
                                    ? 'border-amber-700 text-amber-800'
                                    : 'border-transparent text-stone-500 hover:text-stone-700 hover:border-stone-300'
                            } group inline-flex items-center py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200`}
                        >
                            <tab.icon className={`-ml-0.5 mr-2 h-5 w-5 ${activeTab === tab.id ? 'text-amber-700' : 'text-stone-400 group-hover:text-stone-500'}`} />
                            <span>{tab.name}</span>
                        </button>
                    ))}
                </nav>
            </div>
        </header>
    );
};

export default Header;
