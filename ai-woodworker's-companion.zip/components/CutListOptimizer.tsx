
import React, { useState, useCallback } from 'react';
import { generateQuote, getOptimizedCutList } from '../services/geminiService';
import { CutListPart, LumberPiece, OptimizedCutList, MeasurementSystem, ClientDetails, LineItem, GeneratedQuote, Currency } from '../types';
import Card, { CardContent, CardHeader, CardTitle, CardDescription } from './Card';
import Spinner from './Spinner';
import { PlusIcon } from './icons/PlusIcon';
import { TrashIcon } from './icons/TrashIcon';
import QuotePreview from './QuotePreview';
import { CURRENCIES } from '../constants';

// Helper to generate a more compatible unique ID
const generateId = () => `id-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

export const CutListOptimizer: React.FC = () => {
    const [parts, setParts] = useState<CutListPart[]>([
        { id: generateId(), name: 'Shelf', width: 11.25, length: 24, quantity: 4 },
    ]);
    const [lumber, setLumber] = useState<LumberPiece[]>([
        { id: generateId(), width: 11.25, length: 96, quantity: 1 },
    ]);
    const [kerf, setKerf] = useState<number | string>(0.125);
    const [measurementSystem, setMeasurementSystem] = useState<MeasurementSystem>(MeasurementSystem.Imperial);
    
    const [result, setResult] = useState<OptimizedCutList | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    // --- Quote State ---
    const [companyName, setCompanyName] = useState<string>('My Woodworking Shop');
    const [clientDetails, setClientDetails] = useState<ClientDetails>({ name: '', email: '', address: '' });
    const [timberCost, setTimberCost] = useState<number | string>('');
    const [laborHours, setLaborHours] = useState<number | string>('');
    const [laborRate, setLaborRate] = useState<number | string>('');
    const [markupPercent, setMarkupPercent] = useState<number | string>(20);
    const [taxPercent, setTaxPercent] = useState<number | string>(8);
    const [additionalItems, setAdditionalItems] = useState<LineItem[]>([]);
    const [quoteCurrency, setQuoteCurrency] = useState<Currency>(Currency.USD);
    const [generatedQuote, setGeneratedQuote] = useState<GeneratedQuote | null>(null);
    const [quoteLoading, setQuoteLoading] = useState<boolean>(false);
    const [quoteError, setQuoteError] = useState<string | null>(null);

    const handlePartChange = (id: string, field: keyof Omit<CutListPart, 'id'>, value: string | number) => {
        setParts(parts.map(p => p.id === id ? { ...p, [field]: value } : p));
    };

    const handleLumberChange = (id: string, field: keyof Omit<LumberPiece, 'id'>, value: string | number) => {
        setLumber(lumber.map(l => l.id === id ? { ...l, [field]: value } : l));
    };

    const addPart = () => setParts([...parts, { id: generateId(), name: '', width: '', length: '', quantity: '' }]);
    const removePart = (id: string) => setParts(parts.filter(p => p.id !== id));
    
    const addLumber = () => setLumber([...lumber, { id: generateId(), width: '', length: '', quantity: '' }]);
    const removeLumber = (id: string) => setLumber(lumber.filter(l => l.id !== id));

    const handleGenerate = useCallback(async () => {
        setError(null);
        setResult(null);
        setGeneratedQuote(null);

        const validParts = parts.filter(p => p.name && Number(p.width) > 0 && Number(p.length) > 0 && Number(p.quantity) > 0);
        const validLumber = lumber.filter(l => Number(l.width) > 0 && Number(l.length) > 0 && Number(l.quantity) > 0);
        const validKerf = Number(kerf) >= 0;

        if (validParts.length === 0 || validLumber.length === 0 || !validKerf) {
            setError('Please ensure all parts, lumber, and kerf have valid, positive values.');
            return;
        }

        setLoading(true);
        try {
            const apiResult = await getOptimizedCutList(
                validParts.map(p => ({...p, width: Number(p.width), length: Number(p.length), quantity: Number(p.quantity)})), 
                validLumber.map(l => ({...l, width: Number(l.width), length: Number(l.length), quantity: Number(l.quantity)})), 
                Number(kerf), 
                measurementSystem
            );
            setResult(apiResult);
        } catch (err) {
            setError('Failed to generate cut list. The model may have had an issue with the provided dimensions.');
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, [parts, lumber, kerf, measurementSystem]);
    
    const unit = measurementSystem === MeasurementSystem.Imperial ? 'in' : 'mm';

    // --- Quote Functions ---
    const addAdditionalItem = () => setAdditionalItems([...additionalItems, { id: generateId(), description: '', cost: '' }]);
    const removeAdditionalItem = (id: string) => setAdditionalItems(additionalItems.filter(item => item.id !== id));
    const handleAdditionalItemChange = (id: string, field: 'description' | 'cost', value: string) => {
        setAdditionalItems(additionalItems.map(item => item.id === id ? { ...item, [field]: value } : item));
    };

    const handleGenerateQuote = async () => {
        setQuoteError(null);
        setGeneratedQuote(null);

        const validItems = additionalItems.filter(item => item.description && Number(item.cost) > 0);
        const validClient = clientDetails.name && clientDetails.email;

        if (!validClient || !companyName || Number(timberCost) <= 0 || Number(laborHours) <= 0 || Number(laborRate) <= 0) {
            setQuoteError("Please fill in your company name, all client details, and all cost fields with valid numbers.");
            return;
        }

        setQuoteLoading(true);
        try {
            const quote = await generateQuote(
                companyName,
                clientDetails,
                Number(timberCost),
                Number(laborHours),
                Number(laborRate),
                Number(markupPercent),
                Number(taxPercent),
                validItems.map(({id, ...rest}) => ({...rest, cost: Number(rest.cost)})),
                quoteCurrency
            );
            setGeneratedQuote(quote);
        } catch(err) {
            setQuoteError("The AI failed to generate a quote. Please check your inputs and try again.");
            console.error(err);
        } finally {
            setQuoteLoading(false);
        }
    }
    
    const currencySymbol = quoteCurrency === Currency.USD ? '$' : quoteCurrency === Currency.GBP ? '£' : '€';


    return (
        <div className="max-w-7xl mx-auto">
            <Card className="mb-6">
                <CardHeader>
                    <CardTitle>Cut List Optimizer</CardTitle>
                    <CardDescription>Enter the parts you need and the lumber you have to get an AI-optimized cutting plan that minimizes waste.</CardDescription>
                </CardHeader>
                <CardContent>
                    {/* Measurement System Toggle */}
                    <div className="mb-6">
                        <span className="text-sm font-medium text-stone-700 mr-4">Measurement System:</span>
                        <div className="inline-flex rounded-md shadow-sm">
                            <button onClick={() => setMeasurementSystem(MeasurementSystem.Imperial)} className={`px-4 py-2 text-sm font-medium rounded-l-lg border ${measurementSystem === MeasurementSystem.Imperial ? 'bg-amber-700 text-white border-amber-700 z-10' : 'bg-white text-stone-700 border-stone-300 hover:bg-stone-50'}`}>Imperial (in)</button>
                            <button onClick={() => setMeasurementSystem(MeasurementSystem.Metric)} className={`-ml-px px-4 py-2 text-sm font-medium rounded-r-lg border ${measurementSystem === MeasurementSystem.Metric ? 'bg-amber-700 text-white border-amber-700 z-10' : 'bg-white text-stone-700 border-stone-300 hover:bg-stone-50'}`}>Metric (mm)</button>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        {/* Parts Input */}
                        <div className="space-y-4">
                            <h3 className="text-lg font-semibold text-stone-700">Parts to Cut</h3>
                            {parts.map((part) => (
                                <div key={part.id} className="grid grid-cols-12 gap-2 p-3 bg-stone-50 rounded-lg border">
                                    <input type="text" placeholder="Name" value={part.name} onChange={e => handlePartChange(part.id, 'name', e.target.value)} className="col-span-12 md:col-span-3 p-2 border bg-white border-stone-300 rounded-md" />
                                    <input type="number" placeholder={`Length (${unit})`} value={part.length} onChange={e => handlePartChange(part.id, 'length', Number(e.target.value))} className="col-span-4 md:col-span-2 p-2 border bg-white border-stone-300 rounded-md" />
                                    <input type="number" placeholder={`Width (${unit})`} value={part.width} onChange={e => handlePartChange(part.id, 'width', Number(e.target.value))} className="col-span-4 md:col-span-2 p-2 border bg-white border-stone-300 rounded-md" />
                                    <input type="number" placeholder="Qty" value={part.quantity} onChange={e => handlePartChange(part.id, 'quantity', Number(e.target.value))} className="col-span-4 md:col-span-2 p-2 border bg-white border-stone-300 rounded-md" />
                                    <button onClick={() => removePart(part.id)} className="col-span-12 md:col-span-3 flex justify-center items-center bg-red-100 text-red-600 hover:bg-red-200 rounded-md"><TrashIcon className="h-5 w-5"/></button>
                                </div>
                            ))}
                            <button onClick={addPart} className="flex items-center gap-2 text-sm font-medium text-amber-800 hover:text-amber-900"><PlusIcon className="h-5 w-5"/>Add Part</button>
                        </div>

                        {/* Lumber Input */}
                        <div className="space-y-4">
                             <h3 className="text-lg font-semibold text-stone-700">Available Lumber</h3>
                            {lumber.map((l) => (
                                <div key={l.id} className="grid grid-cols-12 gap-2 p-3 bg-stone-50 rounded-lg border">
                                    <input type="number" placeholder={`Length (${unit})`} value={l.length} onChange={e => handleLumberChange(l.id, 'length', Number(e.target.value))} className="col-span-4 md:col-span-3 p-2 border bg-white border-stone-300 rounded-md" />
                                    <input type="number" placeholder={`Width (${unit})`} value={l.width} onChange={e => handleLumberChange(l.id, 'width', Number(e.target.value))} className="col-span-4 md:col-span-3 p-2 border bg-white border-stone-300 rounded-md" />
                                    <input type="number" placeholder="Qty" value={l.quantity} onChange={e => handleLumberChange(l.id, 'quantity', Number(e.target.value))} className="col-span-4 md:col-span-3 p-2 border bg-white border-stone-300 rounded-md" />
                                    <button onClick={() => removeLumber(l.id)} className="col-span-12 md:col-span-3 flex justify-center items-center bg-red-100 text-red-600 hover:bg-red-200 rounded-md"><TrashIcon className="h-5 w-5"/></button>
                                </div>
                            ))}
                            <button onClick={addLumber} className="flex items-center gap-2 text-sm font-medium text-amber-800 hover:text-amber-900"><PlusIcon className="h-5 w-5"/>Add Lumber</button>
                        </div>
                    </div>

                     {/* Kerf and Generate Button */}
                     <div className="mt-8 pt-6 border-t">
                        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                             <div>
                                <label htmlFor="kerf" className="block text-sm font-medium text-stone-700 text-center sm:text-left">Saw Blade Kerf ({unit})</label>
                                <input type="number" id="kerf" value={kerf} onChange={e => setKerf(e.target.value)} className="mt-1 w-32 border border-stone-300 bg-white rounded-md shadow-sm py-2 px-3"/>
                             </div>
                             <button onClick={handleGenerate} disabled={loading} className="w-full sm:w-auto px-8 py-3 bg-amber-700 text-white font-semibold rounded-lg shadow-md hover:bg-amber-800 disabled:bg-stone-400 transition-colors">
                                {loading ? 'Optimizing...' : 'Generate Cut List'}
                             </button>
                        </div>
                     </div>
                </CardContent>
            </Card>

            {loading && <div className="flex justify-center mt-8"><Spinner text="Finding the best layout..." /></div>}
            {error && <div className="mt-6 text-center text-red-600 bg-red-100 p-4 rounded-md">{error}</div>}

            {result && !loading && (
                <div className="space-y-6 animate-fade-in mt-6">
                    <Card>
                        <CardHeader>
                            <CardTitle>Optimization Results</CardTitle>
                        </CardHeader>
                        <CardContent>
                           <p className="text-stone-700">{result.summary}</p>
                            {result.unfittableParts.length > 0 && (
                                <div className="mt-4 p-4 bg-yellow-100 border border-yellow-200 rounded-lg">
                                    <h4 className="font-semibold text-yellow-800">Unfittable Parts:</h4>
                                    <ul className="list-disc list-inside text-yellow-700">
                                        {result.unfittableParts.map((p, i) => <li key={i}>{p.quantity}x {p.name}</li>)}
                                    </ul>
                                </div>
                           )}
                        </CardContent>
                    </Card>
                    
                    <h3 className="text-2xl font-bold text-stone-800 text-center">Cutting Diagrams</h3>
                    
                    <div className="space-y-8">
                        {result.layouts.map((layout, i) => (
                            <Card key={i}>
                                <CardHeader>
                                    <CardTitle>Board #{layout.lumberPieceIndex + 1} Layout</CardTitle>
                                    <CardDescription>Original Dimensions: {lumber[layout.lumberPieceIndex].length}" x {lumber[layout.lumberPieceIndex].width}" | Waste: {layout.wastePercentage.toFixed(2)}%</CardDescription>
                                </CardHeader>
                                <CardContent className="bg-stone-50 p-4 overflow-x-auto">
                                    <div
                                        className="max-w-full"
                                        style={{ width: `${layout.usedLumberDimensions.length}px`, height: `${layout.usedLumberDimensions.width}px`}}
                                        dangerouslySetInnerHTML={{__html: layout.svg}}
                                    />
                                </CardContent>
                            </Card>
                        ))}
                    </div>

                    {/* --- QUOTE GENERATOR --- */}
                    <Card className="mt-8">
                        <CardHeader>
                            <CardTitle>Create a Quote</CardTitle>
                            <CardDescription>Generate a professional quote for your client based on this project.</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-6">
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-4 p-4 bg-stone-50 rounded-lg border">
                                    <h4 className="font-semibold">Your Details</h4>
                                    <input type="text" placeholder="Company Name" value={companyName} onChange={e => setCompanyName(e.target.value)} className="w-full p-2 border bg-white rounded-md"/>
                                     <div>
                                        <label htmlFor="quoteCurrency" className="block text-sm font-medium text-stone-700">Quote Currency</label>
                                        <select
                                            id="quoteCurrency"
                                            value={quoteCurrency}
                                            onChange={(e) => setQuoteCurrency(e.target.value as Currency)}
                                            className="mt-1 block w-full border border-stone-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-amber-500 focus:border-amber-500 bg-white"
                                        >
                                            {CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
                                        </select>
                                    </div>
                                </div>
                                <div className="space-y-4 p-4 bg-stone-50 rounded-lg border">
                                    <h4 className="font-semibold">Client Details</h4>
                                    <input type="text" placeholder="Client Name" value={clientDetails.name} onChange={e => setClientDetails({...clientDetails, name: e.target.value})} className="w-full p-2 border bg-white rounded-md"/>
                                    <input type="email" placeholder="Client Email" value={clientDetails.email} onChange={e => setClientDetails({...clientDetails, email: e.target.value})} className="w-full p-2 border bg-white rounded-md"/>
                                    <textarea placeholder="Client Address" value={clientDetails.address} onChange={e => setClientDetails({...clientDetails, address: e.target.value})} className="w-full p-2 border bg-white rounded-md" rows={2}/>
                                </div>
                            </div>
                            
                            <div className="space-y-4 p-4 bg-stone-50 rounded-lg border">
                                <h4 className="font-semibold">Project Costs</h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                     <input type="number" placeholder={`Total Timber Cost (${currencySymbol})`} value={timberCost} onChange={e => setTimberCost(e.target.value)} className="w-full p-2 border bg-white rounded-md"/>
                                     <input type="number" placeholder="Labor Hours" value={laborHours} onChange={e => setLaborHours(e.target.value)} className="w-full p-2 border bg-white rounded-md"/>
                                     <input type="number" placeholder={`Hourly Rate (${currencySymbol})`} value={laborRate} onChange={e => setLaborRate(e.target.value)} className="w-full p-2 border bg-white rounded-md"/>
                                </div>
                            </div>

                             <div className="space-y-4 p-4 bg-stone-50 rounded-lg border">
                                <h4 className="font-semibold">Additional Items (Hardware, Finishes, etc.)</h4>
                                {additionalItems.map(item => (
                                    <div key={item.id} className="flex gap-2">
                                        <input type="text" placeholder="Item Description" value={item.description} onChange={e => handleAdditionalItemChange(item.id, 'description', e.target.value)} className="flex-grow p-2 border bg-white rounded-md"/>
                                        <input type="number" placeholder={`Cost (${currencySymbol})`} value={item.cost} onChange={e => handleAdditionalItemChange(item.id, 'cost', e.target.value)} className="w-32 p-2 border bg-white rounded-md"/>
                                        <button onClick={() => removeAdditionalItem(item.id)} className="p-2 bg-red-100 text-red-600 hover:bg-red-200 rounded-md"><TrashIcon className="h-5 w-5"/></button>
                                    </div>
                                ))}
                                <button onClick={addAdditionalItem} className="flex items-center gap-2 text-sm font-medium text-amber-800 hover:text-amber-900"><PlusIcon className="h-5 w-5"/>Add Item</button>
                            </div>

                            <div className="space-y-4 p-4 bg-stone-50 rounded-lg border">
                                <h4 className="font-semibold">Financials</h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-sm font-medium">Markup (%)</label>
                                        <input type="number" placeholder="e.g., 20" value={markupPercent} onChange={e => setMarkupPercent(e.target.value)} className="w-full p-2 border bg-white rounded-md"/>
                                    </div>
                                    <div>
                                        <label className="text-sm font-medium">Tax (%)</label>
                                        <input type="number" placeholder="e.g., 8" value={taxPercent} onChange={e => setTaxPercent(e.target.value)} className="w-full p-2 border bg-white rounded-md"/>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="text-center pt-4">
                                <button onClick={handleGenerateQuote} disabled={quoteLoading} className="px-8 py-3 bg-green-700 text-white font-semibold rounded-lg shadow-md hover:bg-green-800 disabled:bg-stone-400 transition-colors">
                                    {quoteLoading ? 'Generating Quote...' : 'Generate Quote'}
                                </button>
                            </div>
                            {quoteError && <div className="mt-4 text-center text-red-600 bg-red-100 p-4 rounded-md">{quoteError}</div>}
                        </CardContent>
                    </Card>
                </div>
            )}
            
            {quoteLoading && <div className="flex justify-center mt-8"><Spinner text="Preparing your quote..." /></div>}

            {generatedQuote && <QuotePreview quote={generatedQuote} />}
        </div>
    );
};
