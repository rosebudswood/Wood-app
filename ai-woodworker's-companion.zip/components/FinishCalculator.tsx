
import React, { useState, useCallback } from 'react';
import { calculateFinish } from '../services/geminiService';
import { FinishCalculation } from '../types';
import { FINISH_TYPES } from '../constants';
import Card, { CardContent, CardHeader, CardTitle } from './Card';
import Spinner from './Spinner';

const FinishCalculator: React.FC = () => {
    const [area, setArea] = useState<number | string>('');
    const [coats, setCoats] = useState<number | string>(2);
    const [finishType, setFinishType] = useState<string>(FINISH_TYPES[0]);
    const [customFinishType, setCustomFinishType] = useState<string>('');
    const [showCustom, setShowCustom] = useState(false);
    const [result, setResult] = useState<FinishCalculation | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const handleCalculate = useCallback(async () => {
        const finalFinishType = showCustom ? customFinishType : finishType;
        if (!area || !coats || Number(area) <= 0 || Number(coats) <= 0 || !finalFinishType) {
            setError('Please fill all fields with valid values.');
            return;
        }
        
        setLoading(true);
        setError(null);
        setResult(null);

        try {
            const calculationResult = await calculateFinish(Number(area), Number(coats), finalFinishType);
            setResult(calculationResult);
        } catch (err) {
            setError('Failed to perform calculation. Please try again.');
            console.error(err);
        } finally {
            setLoading(false);
        }

    }, [area, coats, finishType, customFinishType, showCustom]);
    
    const handleFinishTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const value = e.target.value;
        if (value === 'Other') {
            setShowCustom(true);
            setFinishType('Other');
        } else {
            setShowCustom(false);
            setFinishType(value);
            setCustomFinishType('');
        }
    };

    return (
        <div className="max-w-2xl mx-auto">
            <Card>
                <CardHeader>
                    <CardTitle>Finish Calculator</CardTitle>
                    <p className="text-stone-600 mt-1">Estimate how much finish you'll need for your project.</p>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <label htmlFor="area" className="block text-sm font-medium text-stone-700">Total Surface Area (sq. ft.)</label>
                        <input
                            type="number"
                            id="area"
                            value={area}
                            onChange={(e) => setArea(e.target.value)}
                            className="mt-1 block w-full border border-stone-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-amber-500 focus:border-amber-500"
                            placeholder="e.g., 25"
                        />
                    </div>
                    <div>
                        <label htmlFor="coats" className="block text-sm font-medium text-stone-700">Number of Coats</label>
                        <input
                            type="number"
                            id="coats"
                            value={coats}
                            onChange={(e) => setCoats(e.target.value)}
                            className="mt-1 block w-full border border-stone-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-amber-500 focus:border-amber-500"
                        />
                    </div>
                    <div>
                        <label htmlFor="finishType" className="block text-sm font-medium text-stone-700">Type of Finish</label>
                        <select 
                            id="finishType"
                            value={finishType}
                            onChange={handleFinishTypeChange}
                             className="mt-1 block w-full border border-stone-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-amber-500 focus:border-amber-500"
                        >
                            {FINISH_TYPES.map(type => <option key={type} value={type}>{type}</option>)}
                            <option value="Other">Other...</option>
                        </select>
                    </div>
                    {showCustom && (
                         <div className="animate-fade-in">
                            <label htmlFor="customFinishType" className="block text-sm font-medium text-stone-700">Custom Finish Type</label>
                            <input
                                type="text"
                                id="customFinishType"
                                value={customFinishType}
                                onChange={(e) => setCustomFinishType(e.target.value)}
                                className="mt-1 block w-full border border-stone-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-amber-500 focus:border-amber-500"
                                placeholder="e.g., Hardwax Oil"
                            />
                        </div>
                    )}
                    <div className="text-center pt-2">
                        <button
                            onClick={handleCalculate}
                            disabled={loading}
                            className="w-full sm:w-auto px-8 py-2 bg-amber-700 text-white font-semibold rounded-lg shadow-md hover:bg-amber-800 disabled:bg-stone-400 transition-colors"
                        >
                            {loading ? 'Calculating...' : 'Calculate'}
                        </button>
                    </div>
                </CardContent>
            </Card>

            {loading && <div className="flex justify-center mt-8"><Spinner text="Calculating..." /></div>}
            {error && <div className="mt-6 text-center text-red-600 bg-red-100 p-4 rounded-md">{error}</div>}

            {result && (
                <Card className="mt-6 animate-fade-in">
                    <CardHeader>
                        <CardTitle>Calculation Result</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-center space-y-4">
                            <div>
                                <p className="text-stone-600">Estimated Amount Needed:</p>
                                <p className="text-3xl font-bold text-amber-800">{result.ounces.toFixed(2)} fl. oz.</p>
                                <p className="text-lg text-stone-700">({result.gallons.toFixed(3)} US Gallons)</p>
                            </div>
                            <div className="bg-stone-100 p-4 rounded-lg">
                                 <h4 className="font-semibold text-stone-700">Recommendation</h4>
                                 <p className="text-stone-600 mt-1">{result.recommendation}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
};

export default FinishCalculator;
