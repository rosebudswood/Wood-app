
import React, { useRef, useEffect, useState } from 'react';
import Spinner from './Spinner';

interface CameraCaptureProps {
    onCapture: (imageDataUrl: string) => void;
    onCancel: () => void;
}

const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture, onCancel }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const startCamera = async () => {
            setLoading(true);
            setError(null);
            try {
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                    const mediaStream = await navigator.mediaDevices.getUserMedia({ 
                        video: { facingMode: 'environment' } 
                    });
                    setStream(mediaStream);
                    if (videoRef.current) {
                        videoRef.current.srcObject = mediaStream;
                    }
                } else {
                     setError("Your browser does not support camera access.");
                }
            } catch (err) {
                console.error("Error accessing camera:", err);
                setError("Could not access camera. Please ensure you have given permission.");
            } finally {
                setLoading(false);
            }
        };

        startCamera();

        return () => {
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
            }
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleCanPlay = () => {
        setLoading(false);
    };

    const handleCapture = () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            if (context) {
                context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
                const imageDataUrl = canvas.toDataURL('image/jpeg');
                onCapture(imageDataUrl);
                // Stop the stream after capture
                if (stream) {
                    stream.getTracks().forEach(track => track.stop());
                }
            }
        }
    };

    return (
        <div className="max-w-lg mx-auto bg-white p-4 rounded-lg shadow-xl animate-fade-in">
            <h3 className="text-xl font-bold text-stone-800 text-center mb-4">Camera View</h3>
            <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden">
                {loading && (
                    <div className="absolute inset-0 flex items-center justify-center z-10">
                        <Spinner text="Starting camera..." />
                    </div>
                )}
                {error && (
                     <div className="absolute inset-0 flex items-center justify-center z-10 p-4">
                        <p className="text-center text-red-400">{error}</p>
                    </div>
                )}
                <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    onCanPlay={handleCanPlay}
                    className={`w-full h-full object-cover ${loading || error ? 'hidden' : ''}`}
                />
                 <canvas ref={canvasRef} className="hidden" />
            </div>
            <div className="mt-4 flex justify-center gap-4">
                 <button
                    onClick={onCancel}
                    className="px-6 py-2 bg-stone-200 text-stone-700 font-semibold rounded-lg shadow-sm hover:bg-stone-300 transition-colors"
                >
                    Cancel
                </button>
                <button
                    onClick={handleCapture}
                    disabled={loading || !!error}
                    className="px-6 py-2 bg-amber-700 text-white font-semibold rounded-lg shadow-md hover:bg-amber-800 disabled:bg-stone-400 transition-colors"
                >
                    Capture Image
                </button>
            </div>
        </div>
    );
};

export default CameraCapture;
