
import React from 'react';

export const HammerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="m15 12-8.373 8.373a1 1 0 1 1-1.414-1.414L12 12.414" />
    <path d="m22 2-5.657 5.657" />
    <path d="m11.343 12.657-6 6" />
    <path d="m3 21 6-6" />
    <path d="M17.657 8.657 13.414 12.9" />
    <path d="m9.232 2.232 4.243 4.242a1 1 0 0 1 0 1.414l-4.243 4.243a1 1 0 0 1-1.414 0l-4.243-4.243a1 1 0 0 1 0-1.414l4.243-4.243a1 1 0 0 1 1.414 0z" />
  </svg>
);
