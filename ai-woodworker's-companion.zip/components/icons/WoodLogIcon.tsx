
import React from 'react';

export const WoodLogIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M12 22a2.8 2.8 0 0 0 3-2.1l1.4-6.5a2.8 2.8 0 0 0-3.8-3.2L3 12.8V19a3 3 0 0 0 3 3h6z" />
    <path d="M3.2 11.2a2.8 2.8 0 0 0 3.2 3.8l12-4.5a2.8 2.8 0 0 0 2-3.2A2.8 2.8 0 0 0 17.2 3l-12 4.5a2.8 2.8 0 0 0-2 3.7z" />
    <path d="M9 12.8c-2.4 1.3-3.6 4-3 6.4" />
    <path d="M18.8 8.8c-1.3 2.4-4 3.6-6.4 3" />
    <path d="m21.6 6.4-12 4.5" />
  </svg>
);
