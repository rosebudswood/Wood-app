
import React from 'react';

interface CardProps {
    children: React.ReactNode;
    className?: string;
    id?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '', id }) => {
    return (
        <div id={id} className={`bg-white rounded-lg shadow-lg overflow-hidden transition-shadow hover:shadow-xl ${className}`}>
            {children}
        </div>
    );
};

export const CardContent: React.FC<CardProps> = ({ children, className = '', id }) => {
    return <div className={`p-6 ${className}`} id={id}>{children}</div>;
};

export const CardHeader: React.FC<CardProps> = ({ children, className = '', id }) => {
    return <div className={`p-6 border-b border-stone-200 ${className}`} id={id}>{children}</div>;
};

export const CardTitle: React.FC<CardProps> = ({ children, className = '', id }) => {
    return <h3 className={`text-xl font-bold text-stone-800 ${className}`} id={id}>{children}</h3>;
};

export const CardDescription: React.FC<CardProps> = ({ children, className = '', id }) => {
    return <p className={`mt-1 text-stone-600 ${className}`} id={id}>{children}</p>;
};


export default Card;