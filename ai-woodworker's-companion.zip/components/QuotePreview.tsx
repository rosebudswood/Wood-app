
import React from 'react';
import { GeneratedQuote } from '../types';
import Card, { CardContent, CardHeader, CardTitle, CardDescription } from './Card';
import { PrintIcon } from './icons/PrintIcon';

interface QuotePreviewProps {
    quote: GeneratedQuote;
}

const getCurrencySymbol = (currency: GeneratedQuote['currency']) => {
    switch (currency) {
        case 'USD': return '$';
        case 'GBP': return '£';
        case 'EUR': return '€';
        default: return '$';
    }
}

const QuotePreview: React.FC<QuotePreviewProps> = ({ quote }) => {
    
    const handlePrint = () => {
        window.print();
    };

    const symbol = getCurrencySymbol(quote.currency);
    
    return (
        <div className="mt-8 animate-fade-in print-container">
            <style>
                {`
                @media print {
                    body * {
                        visibility: hidden;
                    }
                    .print-container, .print-container * {
                        visibility: visible;
                    }
                    .print-container {
                        position: absolute;
                        left: 0;
                        top: 0;
                        width: 100%;
                    }
                    .no-print {
                        display: none;
                    }
                }
                `}
            </style>
            <Card>
                <CardHeader className="flex justify-between items-center">
                    <div>
                        <CardTitle>Quote Preview</CardTitle>
                        <CardDescription>This is how your quote will look when printed.</CardDescription>
                    </div>
                    <button onClick={handlePrint} className="no-print flex items-center gap-2 px-4 py-2 bg-stone-600 text-white font-semibold rounded-lg shadow-md hover:bg-stone-700 transition-colors">
                        <PrintIcon className="h-5 w-5"/>
                        Print Quote
                    </button>
                </CardHeader>
                <CardContent id="printable-quote">
                    <div className="p-8 border border-stone-200 rounded-lg bg-white">
                        {/* Header */}
                        <div className="flex justify-between items-start pb-6 border-b">
                            <div>
                                <h1 className="text-3xl font-bold text-stone-800">{quote.companyName}</h1>
                            </div>
                            <div className="text-right">
                                <h2 className="text-2xl font-semibold text-stone-700">QUOTE</h2>
                                <p className="text-stone-500">#{quote.quoteNumber}</p>
                                <p className="text-stone-500">Date: {quote.date}</p>
                            </div>
                        </div>

                        {/* From/To Details */}
                        <div className="grid grid-cols-2 gap-8 my-8">
                            <div>
                                <h3 className="font-semibold text-stone-500 uppercase tracking-wide text-sm mb-2">BILL TO</h3>
                                <p className="font-bold text-stone-800">{quote.clientDetails.name}</p>
                                <p className="text-stone-600">{quote.clientDetails.address}</p>
                                <p className="text-stone-600">{quote.clientDetails.email}</p>
                            </div>
                        </div>

                        {/* Items Table */}
                        <div className="flow-root">
                           <table className="min-w-full divide-y divide-stone-300">
                                <thead>
                                    <tr>
                                        <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-stone-900 sm:pl-0">Item</th>
                                        <th scope="col" className="px-3 py-3.5 text-right text-sm font-semibold text-stone-900">Cost</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-stone-200">
                                    {quote.costBreakdown.map((item, index) => (
                                        <tr key={index}>
                                            <td className="w-full max-w-0 py-4 pl-4 pr-3 text-sm font-medium text-stone-900 sm:w-auto sm:max-w-none sm:pl-0">{item.item}</td>
                                            <td className="px-3 py-4 text-sm text-right text-stone-500">{symbol}{item.cost.toFixed(2)}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                        {/* Totals Section */}
                        <div className="mt-8 ml-auto max-w-xs text-right">
                            <div className="space-y-2">
                                <div className="flex justify-between">
                                    <span className="font-medium text-stone-600">Subtotal:</span>
                                    <span>{symbol}{quote.subtotal.toFixed(2)}</span>
                                </div>
                                 <div className="flex justify-between">
                                    <span className="font-medium text-stone-600">Markup:</span>
                                    <span>{symbol}{quote.markupAmount.toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="font-medium text-stone-600">Tax:</span>
                                    <span>{symbol}{quote.taxAmount.toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between pt-2 border-t text-lg font-bold text-stone-800">
                                    <span>Grand Total:</span>
                                    <span>{symbol}{quote.grandTotal.toFixed(2)}</span>
                                </div>
                            </div>
                        </div>

                        {/* Footer Notes */}
                        <div className="mt-12 pt-6 border-t">
                            <h4 className="font-semibold text-stone-700">Notes</h4>
                            <p className="text-sm text-stone-600 mt-1">{quote.notes}</p>
                        </div>

                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

export default QuotePreview;
