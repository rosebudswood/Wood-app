
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { Difficulty, ProjectIdea, Joint, FinishCalculation, WoodIdentification, ToolRecommendations, Budget, Currency, OptimizedCutList, CutListPart, LumberPiece, MeasurementSystem, GeneratedQuote, ClientDetails } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Schemas
const projectIdeasSchema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING, description: "Name of the woodworking project." },
        description: { type: Type.STRING, description: "A brief description of the project." },
        tools: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of required tools." },
        materials: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of required materials." },
      },
      required: ["name", "description", "tools", "materials"],
    },
};

const jointsLibrarySchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            name: { type: Type.STRING },
            description: { type: Type.STRING },
            uses: { type: Type.STRING },
            strength: { type: Type.STRING, description: "e.g., weak, moderate, strong" },
            svg_diagram: {
                type: Type.STRING,
                description: "A valid, 2D instructional line drawing as an SVG string. Use an exploded view to show how parts fit together. Must have a transparent background, viewBox='0 0 24 24', stroke='currentColor', stroke-width='1', and fill='none'. The diagram should be simple and clear for a beginner."
            }
        },
        required: ["name", "description", "uses", "strength", "svg_diagram"]
    }
};

const finishCalculatorSchema = {
    type: Type.OBJECT,
    properties: {
        ounces: { type: Type.NUMBER },
        gallons: { type: Type.NUMBER },
        recommendation: { type: Type.STRING }
    },
    required: ["ounces", "gallons", "recommendation"]
};

const woodIdentificationSchema = {
    type: Type.OBJECT,
    properties: {
        wood_species: { type: Type.STRING, description: "The most likely wood species." },
        characteristics: { type: Type.STRING, description: "Common characteristics like color, grain, hardness." },
        typical_uses: { type: Type.STRING, description: "Typical uses for this type of wood." },
        confidence: { type: Type.STRING, description: "Confidence level for the identification: High, Medium, or Low." },
        confidence_reasoning: { type: Type.STRING, description: "A brief reason for the stated confidence level." }
    },
    required: ["wood_species", "characteristics", "typical_uses", "confidence", "confidence_reasoning"]
};

const toolRecommendationsSchema = {
    type: Type.OBJECT,
    properties: {
        summary: { type: Type.STRING, description: "A brief summary of the tool philosophy for this budget and interest." },
        handTools: {
            type: Type.ARRAY,
            description: "List of essential hand tools.",
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING, description: "Name of the hand tool." },
                    reason: { type: Type.STRING, description: "Brief reason why this tool is recommended for a beginner with the specified budget and interest." }
                },
                required: ["name", "reason"]
            }
        },
        powerTools: {
            type: Type.ARRAY,
            description: "List of essential power tools.",
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING, description: "Name of the power tool." },
                    reason: { type: Type.STRING, description: "Brief reason why this tool is recommended for a beginner with the specified budget and interest." }
                },
                required: ["name", "reason"]
            }
        }
    },
    required: ["summary", "handTools", "powerTools"]
};

const cutListOptimizerSchema = {
    type: Type.OBJECT,
    properties: {
        summary: { type: Type.STRING, description: "A brief summary of the optimization results, mentioning overall waste or efficiency." },
        layouts: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    lumberPieceIndex: { type: Type.INTEGER, description: "0-based index of the lumber piece from the user's input list this layout applies to." },
                    usedLumberDimensions: {
                        type: Type.OBJECT,
                        properties: {
                            width: { type: Type.NUMBER },
                            length: { type: Type.NUMBER }
                        },
                        required: ["width", "length"]
                    },
                    svg: { type: Type.STRING, description: "A valid SVG string representing the lumber board with the cut parts laid out. The viewBox must be '0 0 {length} {width}' of the board. Each cut part should be a <rect> with a <text> label inside showing its name and dimensions. Include a separate rectangle for the waste area. Use different colors for parts and waste. The SVG should be to scale." },
                    wastePercentage: { type: Type.NUMBER, description: "The percentage of this specific lumber piece that is waste." }
                },
                required: ["lumberPieceIndex", "svg", "wastePercentage", "usedLumberDimensions"]
            }
        },
        unfittableParts: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING },
                    quantity: { type: Type.INTEGER }
                },
                required: ["name", "quantity"]
            }
        }
    },
    required: ["summary", "layouts", "unfittableParts"]
};

const generateQuoteSchema = {
    type: Type.OBJECT,
    properties: {
        quoteNumber: { type: Type.STRING, description: "A unique quote number, e.g., Q-2024-001." },
        date: { type: Type.STRING, description: "The current date for the quote." },
        companyName: { type: Type.STRING },
        clientDetails: {
            type: Type.OBJECT,
            properties: {
                name: { type: Type.STRING },
                email: { type: Type.STRING },
                address: { type: Type.STRING }
            },
            required: ["name", "email", "address"]
        },
        costBreakdown: {
            type: Type.ARRAY,
            description: "An itemized list of all costs, including timber, labor, and additional items.",
            items: {
                type: Type.OBJECT,
                properties: {
                    item: { type: Type.STRING, description: "Description of the cost item (e.g., 'Oak Timber', 'Labor (8 hours)', 'Hinges')." },
                    cost: { type: Type.NUMBER }
                },
                required: ["item", "cost"]
            }
        },
        subtotal: { type: Type.NUMBER, description: "The sum of all items in the costBreakdown before markup and tax." },
        markupAmount: { type: Type.NUMBER, description: "The calculated markup amount based on the percentage provided." },
        taxAmount: { type: Type.NUMBER, description: "The calculated tax amount based on the percentage provided." },
        grandTotal: { type: Type.NUMBER, description: "The final total for the client (subtotal + markup + tax)." },
        notes: { type: Type.STRING, description: "Any additional notes for the client, such as payment terms or project timeline." },
        currency: { type: Type.STRING, enum: ["USD", "GBP", "EUR"], description: "The currency of the quote." }
    },
    required: ["quoteNumber", "date", "companyName", "clientDetails", "costBreakdown", "subtotal", "markupAmount", "taxAmount", "grandTotal", "notes", "currency"]
};


// API Functions
const callGemini = async (prompt: string, schema: object) => {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: schema,
        },
    });
    return JSON.parse(response.text);
}

export const getProjectIdeas = async (difficulty: Difficulty): Promise<ProjectIdea[]> => {
    const prompt = `Generate 5 woodworking project ideas for a ${difficulty} skill level.`;
    return callGemini(prompt, projectIdeasSchema);
};

export const getJoints = async (): Promise<Joint[]> => {
    const prompt = `Provide a list of 5 common woodworking joints. For each joint, include its name, a brief description of what it is, its common uses, its relative strength (weak, moderate, or strong), and a simple, clear 2D line drawing of the joint in SVG format.`;
    return callGemini(prompt, jointsLibrarySchema);
};

export const calculateFinish = async (area: number, coats: number, finishType: string): Promise<FinishCalculation> => {
    const prompt = `Calculate the amount of finish needed in fluid ounces and gallons for a surface area of ${area} sq. ft. with ${coats} coats of ${finishType}. Assume a standard coverage rate. Also provide a brief recommendation or tip for applying this type of finish.`;
    return callGemini(prompt, finishCalculatorSchema);
};

export const identifyWood = async (base64Image: string, mimeType: string): Promise<WoodIdentification> => {
    const prompt = "Identify the wood species from this image. Focus on the grain pattern, color, and texture. Provide the most likely species, its common characteristics, typical uses, and your confidence level (High, Medium, or Low) with a brief reason.";
    const imagePart = { inlineData: { data: base64Image, mimeType } };
    const textPart = { text: prompt };

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [imagePart, textPart] },
        config: {
            responseMimeType: 'application/json',
            responseSchema: woodIdentificationSchema,
        },
    });
    return JSON.parse(response.text);
};

export const visualizeStain = async (woodType: string, stainColor: string): Promise<string> => {
    const prompt = `Generate a photorealistic, high-resolution image of a flat block of ${woodType} wood, stained with a ${stainColor} color. The image should be a close-up texture shot, showing the wood grain clearly.`;
    const response = await ai.models.generateImages({
        model: 'imagen-3.0-generate-002',
        prompt: prompt,
        config: {
            numberOfImages: 1,
            outputMimeType: 'image/jpeg',
            aspectRatio: '1:1',
        },
    });
    return response.generatedImages[0].image.imageBytes;
};

export const getToolRecommendations = async (budget: Budget, interest: string, currency: Currency): Promise<ToolRecommendations> => {
    const prompt = `Create a starter kit tool recommendation list for a beginner woodworker with a ${budget} budget and an interest in ${interest}. The recommendations should be appropriate for someone buying tools in a region using ${currency}. Provide a summary of the philosophy, a list of essential hand tools, and a list of essential power tools. For each tool, give a brief reason why it's recommended.`;
    return callGemini(prompt, toolRecommendationsSchema);
};

export const getOptimizedCutList = async (parts: CutListPart[], lumber: LumberPiece[], kerf: number, measurementSystem: MeasurementSystem): Promise<OptimizedCutList> => {
    const prompt = `
        You are a cut list optimizer for a woodworker.
        Your goal is to create the most efficient layout of parts on available lumber to minimize waste.
        
        Measurement System: ${measurementSystem}
        Saw Blade Kerf: ${kerf} ${measurementSystem === 'imperial' ? 'inches' : 'mm'}

        Parts to Cut (name, length, width, quantity):
        ${parts.map(p => `- ${p.name}: ${p.length} x ${p.width}, Qty: ${p.quantity}`).join('\n')}

        Available Lumber (length, width, quantity):
        ${lumber.map(l => `- ${l.length} x ${l.width}, Qty: ${l.quantity}`).join('\n')}

        Instructions:
        1. Arrange the parts on the lumber pieces to minimize waste. Account for the saw kerf in all calculations.
        2. Provide a layout for EACH piece of lumber used.
        3. For each layout, generate a to-scale SVG diagram. The SVG's viewBox must match the lumber dimensions.
        4. In the SVG, each part should be a <rect> with a fill color and a <text> label inside showing its name.
        5. Represent waste areas as separate <rect> elements with a different, lighter fill color.
        6. Calculate the waste percentage for each board.
        7. If any parts cannot fit on the available lumber, list them in the 'unfittableParts' array.
        8. Provide a brief summary of the results.
    `;
    return callGemini(prompt, cutListOptimizerSchema);
};


export const generateQuote = async (
    companyName: string,
    clientDetails: ClientDetails,
    timberCost: number,
    laborHours: number,
    laborRate: number,
    markupPercent: number,
    taxPercent: number,
    additionalItems: Array<{description: string, cost: number}>,
    currency: Currency
): Promise<GeneratedQuote> => {
    const prompt = `
        You are an automated quote generator for a woodworking business.
        Generate a professional quote based on the following details.
        The currency for this quote is ${currency}.

        Company Name: ${companyName}
        Client: ${JSON.stringify(clientDetails)}
        
        Costs:
        - Timber: ${timberCost}
        - Labor: ${laborHours} hours at ${laborRate} per hour.
        - Additional Items: ${JSON.stringify(additionalItems)}

        Financials:
        - Markup: ${markupPercent}% (apply to the subtotal of timber, labor, and additional items).
        - Tax: ${taxPercent}% (apply to the subtotal after markup).

        Instructions:
        1. Create a unique quote number (e.g., Q-YYYY-NNN).
        2. Use today's date.
        3. Create an itemized list for the 'costBreakdown'. It should include separate lines for timber, total labor, and each additional item.
        4. Calculate the subtotal (sum of all costs).
        5. Calculate the markup amount.
        6. Calculate the tax amount.
        7. Calculate the grand total.
        8. Provide some generic notes for the client (e.g., "Quote valid for 30 days. 50% deposit required to begin work.").
        9. Ensure all monetary values are numbers and the final object matches the provided JSON schema.
    `;
    return callGemini(prompt, generateQuoteSchema);
};
