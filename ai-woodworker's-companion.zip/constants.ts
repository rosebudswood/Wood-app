export const WOOD_TYPES = ["Oak", "Pine", "Maple", "Walnut", "Cherry", "Mahogany"];

export const STAIN_COLORS = ["Natural", "Golden Oak", "Dark Walnut", "Cherry", "Ebony", "Classic Gray"];

export const FINISH_TYPES = ["Polyurethane", "Varnish", "Lacquer", "Shellac", "Tung Oil", "Linseed Oil", "Water-Based Finish"];

export const WOODWORKING_INTERESTS = ["General Woodworking", "Furniture Making", "Carving", "Woodturning", "Home DIY"];

export const CURRENCIES = ["USD", "GBP", "EUR"];