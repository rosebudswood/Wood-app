
export interface Tab {
    id: string;
    name: string;
    icon: React.FC<React.SVGProps<SVGSVGElement>>;
}

export enum Difficulty {
    Beginner = 'Beginner',
    Intermediate = 'Intermediate',
    Advanced = 'Advanced'
}

export enum Budget {
    Budget = 'Budget-Friendly',
    Intermediate = 'Intermediate',
    AllIn = 'All-In'
}

export enum Currency {
    USD = 'USD',
    GBP = 'GBP',
    EUR = 'EUR'
}

export enum MeasurementSystem {
    Imperial = 'imperial',
    Metric = 'metric',
}

export interface ProjectIdea {
    name: string;
    description: string;
    tools: string[];
    materials: string[];
}

export interface Joint {
    name: string;
    description: string;
    uses: string;
    strength: string;
    svg_diagram: string;
}

export interface FinishCalculation {
    ounces: number;
    gallons: number;
    recommendation: string;
}

export interface WoodIdentification {
    wood_species: string;
    characteristics: string;
    typical_uses: string;
    confidence: string;
    confidence_reasoning: string;
}

export interface Tool {
    name: string;
    reason: string;
}

export interface ToolRecommendations {
    summary: string;
    handTools: Tool[];
    powerTools: Tool[];
}

export interface CutListPart {
    id: string;
    width: number | string;
    length: number | string;
    quantity: number | string;
    name: string;
}

export interface LumberPiece {
    id: string;
    width: number | string;
    length: number | string;
    quantity: number | string;
}

export interface CutLayout {
    lumberPieceIndex: number;
    svg: string;
    wastePercentage: number;
    usedLumberDimensions: { width: number; length: number; };
}

export interface OptimizedCutList {
    summary: string;
    layouts: CutLayout[];
    unfittableParts: Array<{ name: string; quantity: number }>;
}

export interface QuoteCostItem {
    item: string;
    cost: number;
}

export interface ClientDetails {
    name: string;
    email: string;
    address: string;
}

export interface LineItem {
    id: string;
    description: string;
    cost: number | string;
}

export interface GeneratedQuote {
    quoteNumber: string;
    date: string;
    companyName: string;
    clientDetails: ClientDetails;
    costBreakdown: QuoteCostItem[];
    subtotal: number;
    markupAmount: number;
    taxAmount: number;
    grandTotal: number;
    notes: string;
    currency: Currency;
}