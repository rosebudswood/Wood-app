import React, { useState } from 'react';
import Header from './components/Header';
import ProjectIdeas from './components/ProjectIdeas';
import WoodIdentifier from './components/WoodIdentifier';
import JointsLibrary from './components/JointsLibrary';
import FinishCalculator from './components/FinishCalculator';
import StainVisualizer from './components/StainVisualizer';
import ToolStarterKit from './components/ToolStarterKit';
import { CutListOptimizer } from './components/CutListOptimizer';
import { HammerIcon } from './components/icons/HammerIcon';
import { WoodLogIcon } from './components/icons/WoodLogIcon';
import { BookOpenIcon } from './components/icons/BookOpenIcon';
import { RulerIcon } from './components/icons/RulerIcon';
import { PaintBrushIcon } from './components/icons/PaintBrushIcon';
import { ToolboxIcon } from './components/icons/ToolboxIcon';
import { CutIcon } from './components/icons/CutIcon';
import { Tab } from './types';

const TABS: Tab[] = [
    { id: 'projects', name: 'Project Ideas', icon: HammerIcon },
    { id: 'starter_kit', name: 'Tool Starter Kit', icon: ToolboxIcon },
    { id: 'cutlist', name: 'Cut List Optimizer', icon: CutIcon },
    { id: 'identifier', name: 'Wood Identifier', icon: WoodLogIcon },
    { id: 'joints', name: 'Joints Library', icon: BookOpenIcon },
    { id: 'calculator', name: 'Finish Calculator', icon: RulerIcon },
    { id: 'visualizer', name: 'Stain Visualizer', icon: PaintBrushIcon },
];

const App: React.FC = () => {
    const [activeTab, setActiveTab] = useState<string>('projects');

    const renderContent = () => {
        switch (activeTab) {
            case 'projects':
                return <ProjectIdeas />;
            case 'starter_kit':
                return <ToolStarterKit />;
            case 'cutlist':
                return <CutListOptimizer />;
            case 'identifier':
                return <WoodIdentifier />;
            case 'joints':
                return <JointsLibrary />;
            case 'calculator':
                return <FinishCalculator />;
            case 'visualizer':
                return <StainVisualizer />;
            default:
                return <ProjectIdeas />;
        }
    };

    return (
        <div className="min-h-screen bg-stone-100 text-stone-800">
            <Header tabs={TABS} activeTab={activeTab} setActiveTab={setActiveTab} />
            <main className="p-4 sm:p-6 md:p-8">
                {renderContent()}
            </main>
            <footer className="text-center p-4 text-stone-500 text-sm">
                <p>Built with craftsmanship by the Gemini API</p>
            </footer>
        </div>
    );
};

export default App;