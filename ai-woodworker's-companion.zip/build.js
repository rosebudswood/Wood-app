
const esbuild = require('esbuild');
const fs = require('fs-extra');
const path = require('path');

const apiKey = process.env.API_KEY;

if (!apiKey) {
  console.error('Build Error: API_KEY environment variable not set.');
  process.exit(1);
}

const distDir = path.join(__dirname, 'dist');
const assetsToCopy = ['manifest.json', 'sw.js', 'icons', 'favicon.svg'];

async function build() {
  try {
    // 1. Ensure the distribution directory is clean
    await fs.emptyDir(distDir);
    console.log('Cleaned dist directory.');

    // 2. Run esbuild to bundle and compile the application
    await esbuild.build({
      entryPoints: ['index.tsx'],
      bundle: true,
      outfile: path.join(distDir, 'index.js'),
      minify: true,
      sourcemap: 'inline',
      target: 'esnext',
      jsx: 'automatic',
      loader: { '.ts': 'tsx' },
      // This is the correct way to inject environment variables
      define: {
        'process.env.API_KEY': `"${apiKey}"`,
      },
    });
    console.log('esbuild build successful.');

    // 3. Copy static assets to the dist directory
    for (const asset of assetsToCopy) {
      const sourcePath = path.join(__dirname, asset);
      if (await fs.pathExists(sourcePath)) {
        await fs.copy(sourcePath, path.join(distDir, asset));
        console.log(`Copied ${asset} to dist.`);
      }
    }
    
    // 4. Read, modify, and write index.html
    const indexPath = path.join(__dirname, 'index.html');
    let indexHtmlContent = await fs.readFile(indexPath, 'utf8');

    // Remove the importmap as it's no longer needed with a bundler
    indexHtmlContent = indexHtmlContent.replace(/<script type="importmap">[\s\S]*?<\/script>/s, '');
    
    // Update the script tag to point to the bundled JS file
    indexHtmlContent = indexHtmlContent.replace(
        '<script type="module" src="/index.tsx"></script>', 
        '<script type="module" src="/index.js"></script>'
    );
    
    await fs.writeFile(path.join(distDir, 'index.html'), indexHtmlContent, 'utf8');
    console.log('Updated index.html and copied to dist.');

    console.log('Build finished successfully!');
  } catch (error) {
    console.error('Build failed:', error);
    process.exit(1);
  }
}

build();
