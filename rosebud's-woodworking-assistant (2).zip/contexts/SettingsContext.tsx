import React, { createContext, useState, useContext, ReactNode } from 'react';
import { UnitSystem, Currency } from '../types.ts';

interface SettingsContextType {
  unitSystem: UnitSystem;
  setUnitSystem: React.Dispatch<React.SetStateAction<UnitSystem>>;
  currency: Currency;
  setCurrency: React.Dispatch<React.SetStateAction<Currency>>;
}

const SettingsContext = createContext<SettingsContextType | null>(null);

export const useSettings = () => {
    const context = useContext(SettingsContext);
    if (!context) {
        throw new Error('useSettings must be used within a SettingsProvider');
    }
    return context;
};

export const SettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [unitSystem, setUnitSystem] = useState<UnitSystem>('imperial');
  const [currency, setCurrency] = useState<Currency>('USD');

  const value = { unitSystem, setUnitSystem, currency, setCurrency };

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  );
};
