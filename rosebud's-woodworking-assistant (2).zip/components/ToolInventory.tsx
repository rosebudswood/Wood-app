import React, { useState, useMemo } from 'react';
import { Tool } from '../types.ts';
import useLocalStorage from '../hooks/useLocalStorage.ts';
import { useToast } from '../contexts/ToastContext.tsx';
import Card from './common/Card.tsx';
import Input from './common/Input.tsx';
import Button from './common/Button.tsx';

const ToolInventory: React.FC = () => {
    const [tools, setTools] = useLocalStorage<Tool[]>('rosebud-tools', []);
    const [editingTool, setEditingTool] = useState<Tool | null>(null);
    const [isFormVisible, setIsFormVisible] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [categoryFilter, setCategoryFilter] = useState('');
    const { addToast } = useToast();

    const initialFormState: Omit<Tool, 'id'> = { name: '', category: '', brand: '', notes: '' };
    const [formState, setFormState] = useState(initialFormState);
    
    const categories = useMemo(() => {
        const uniqueCategories = new Set(tools.map(t => t.category).filter(Boolean));
        return ['Hand Tools', 'Power Tools', 'Measurement', 'Safety', 'Finishing', 'Jigs & Accessories', ...uniqueCategories].filter((v, i, a) => a.indexOf(v) === i).sort();
    }, [tools]);

    const filteredTools = useMemo(() => {
        return tools
            .filter(tool => tool.name.toLowerCase().includes(searchTerm.toLowerCase()) || tool.brand.toLowerCase().includes(searchTerm.toLowerCase()))
            .filter(tool => !categoryFilter || tool.category === categoryFilter);
    }, [tools, searchTerm, categoryFilter]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormState(prev => ({ ...prev, [name]: value }));
    };

    const handleSaveTool = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formState.name || !formState.category) {
            addToast('Tool Name and Category are required.', 'error');
            return;
        }

        if (editingTool) {
            setTools(prev => prev.map(t => t.id === editingTool.id ? { ...editingTool, ...formState } : t));
            addToast('Tool updated successfully!', 'success');
        } else {
            setTools(prev => [...prev, { ...formState, id: Date.now() }]);
            addToast('Tool added successfully!', 'success');
        }
        
        setFormState(initialFormState);
        setEditingTool(null);
        setIsFormVisible(false);
    };
    
    const handleEdit = (tool: Tool) => { setEditingTool(tool); setFormState(tool); setIsFormVisible(true); };
    
    const handleDelete = (id: number) => {
        setTools(prev => prev.filter(t => t.id !== id));
        addToast('Tool deleted.', 'info');
    };
    
    const handleAddNew = () => { setEditingTool(null); setFormState(initialFormState); setIsFormVisible(true); }
    const handleCancel = () => { setEditingTool(null); setFormState(initialFormState); setIsFormVisible(false); }

    const handleExport = () => {
        const dataStr = JSON.stringify(tools, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
        const exportFileDefaultName = 'rosebud_tools_export.json';
        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
        addToast('Tool data exported.', 'success');
    };

    const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
        const fileReader = new FileReader();
        if (event.target.files && event.target.files[0]) {
            fileReader.readAsText(event.target.files[0], "UTF-8");
            fileReader.onload = e => {
                try {
                    const importedTools: Tool[] = JSON.parse(e.target?.result as string);
                    if (Array.isArray(importedTools) && importedTools.every(t => 'id' in t && 'name' in t && 'category' in t)) {
                        setTools(importedTools);
                        addToast('Tools imported successfully!', 'success');
                    } else {
                        addToast('Invalid tool file format.', 'error');
                    }
                } catch(err) {
                    addToast('Failed to parse import file.', 'error');
                }
            };
        }
    };

    return (
        <Card>
            <div className="flex flex-wrap justify-between items-start gap-4 mb-6">
                <div>
                    <h2 className="text-2xl font-bold text-slate-100 mb-1">Tool Inventory</h2>
                    <p className="text-slate-400">Keep track of the tools in your workshop.</p>
                </div>
                <div className="flex gap-2">
                    <Button onClick={handleExport} variant="secondary">Export JSON</Button>
                    <label className="px-4 py-2 font-semibold rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 bg-slate-700 text-slate-200 hover:bg-slate-600 focus:ring-slate-500 cursor-pointer">
                        Import JSON
                        <input type="file" className="hidden" accept=".json" onChange={handleImport} />
                    </label>
                    <Button onClick={handleAddNew}>Add New Tool</Button>
                </div>
            </div>

            {isFormVisible && (
                 <form onSubmit={handleSaveTool} className="p-4 bg-slate-800 border border-slate-700 rounded-lg mb-6 space-y-4">
                     <h3 className="text-lg font-semibold text-rose-400">{editingTool ? 'Edit Tool' : 'Add New Tool'}</h3>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Input label="Tool Name" name="name" value={formState.name} onChange={handleInputChange} placeholder="e.g., Cordless Drill" required />
                        <div>
                             <label htmlFor="category" className="block text-sm font-medium text-slate-400 mb-1">Category</label>
                             <select id="category" name="category" value={formState.category} onChange={handleInputChange} required className="block w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-rose-500 focus:border-rose-500 sm:text-sm text-white">
                                <option value="" disabled>Select a category</option>
                                {categories.map(c => <option key={c} value={c}>{c}</option>)}
                             </select>
                        </div>
                        <Input label="Brand (Optional)" name="brand" value={formState.brand} onChange={handleInputChange} placeholder="e.g., DeWalt" />
                     </div>
                     <div>
                        <label htmlFor="notes" className="block text-sm font-medium text-slate-400 mb-1">Notes (Optional)</label>
                        <textarea id="notes" name="notes" value={formState.notes} onChange={handleInputChange} rows={3} className="block w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-md shadow-sm placeholder-slate-500 focus:outline-none focus:ring-rose-500 focus:border-rose-500 sm:text-sm text-white" placeholder="e.g., Purchase date, specific model..."/>
                     </div>
                     <div className="flex justify-end gap-2">
                        <Button type="button" variant="secondary" onClick={handleCancel}>Cancel</Button>
                        <Button type="submit" variant="primary">{editingTool ? 'Save Changes' : 'Add Tool'}</Button>
                     </div>
                 </form>
            )}

            <div className="flex flex-wrap gap-4 mb-4">
                <div className="flex-grow">
                    <Input label="" id="search-tools" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Search by name or brand..." />
                </div>
                <div>
                    <select id="category-filter" value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)} className="block w-full h-10 px-3 py-2 bg-slate-900 border border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-rose-500 focus:border-rose-500 sm:text-sm text-white">
                        <option value="">All Categories</option>
                        {categories.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                </div>
            </div>

            <div className="overflow-x-auto bg-slate-900/50 rounded-lg border border-slate-700/50">
                <table className="min-w-full divide-y divide-slate-700">
                    <thead className="bg-slate-800">
                        <tr>{['Name', 'Category', 'Brand', 'Notes', 'Actions'].map(h => <th key={h} className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">{h}</th>)}</tr>
                    </thead>
                    <tbody className="bg-slate-800/50 divide-y divide-slate-700">
                        {filteredTools.length === 0 ? (
                            <tr><td colSpan={5} className="px-6 py-12 text-center text-slate-400">No tools found.</td></tr>
                        ) : filteredTools.map(tool => (
                            <tr key={tool.id} className="hover:bg-slate-700/50">
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-200">{tool.name}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-300">{tool.category}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-300">{tool.brand || '-'}</td>
                                <td className="px-6 py-4 whitespace-normal text-sm text-slate-300 max-w-xs truncate">{tool.notes || '-'}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-4">
                                    <button onClick={() => handleEdit(tool)} className="text-rose-500 hover:text-rose-400">Edit</button>
                                    <button onClick={() => handleDelete(tool.id)} className="text-slate-500 hover:text-slate-400">Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </Card>
    );
};

export default ToolInventory;