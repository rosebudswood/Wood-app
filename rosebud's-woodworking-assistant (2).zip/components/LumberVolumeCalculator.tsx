import React, { useState, useMemo, useEffect } from 'react';
import Card from './common/Card.tsx';
import Input from './common/Input.tsx';
import { useSettings } from '../contexts/SettingsContext.tsx';

const LumberVolumeCalculator: React.FC = () => {
  const { unitSystem } = useSettings();
  const isImperial = unitSystem === 'imperial';
  const unitLabel = isImperial ? 'in' : 'cm';
  const volumeUnit = isImperial ? 'Board Feet' : 'm³';

  const [length, setLength] = useState(isImperial ? '96' : '244');
  const [width, setWidth] = useState(isImperial ? '6' : '15');
  const [thickness, setThickness] = useState(isImperial ? '1.5' : '4');
  const [quantity, setQuantity] = useState('1');

  useEffect(() => {
    // Reset to sensible defaults when unit system changes
    setLength(isImperial ? '96' : '244');
    setWidth(isImperial ? '6' : '15');
    setThickness(isImperial ? '1.5' : '4');
  }, [isImperial]);


  const { volumePerPiece, totalVolume, error } = useMemo(() => {
    const L = parseFloat(length);
    const W = parseFloat(width);
    const T = parseFloat(thickness);
    const Q = parseInt(quantity, 10);

    if (isNaN(L) || isNaN(W) || isNaN(T) || isNaN(Q) || L <= 0 || W <= 0 || T <= 0 || Q <= 0) {
      return { error: 'Please enter valid, positive numbers for all dimensions.' };
    }

    let volPerPiece = 0;
    if (isImperial) {
      // Board Foot = (L" * W" * T") / 144
      volPerPiece = (L * W * T) / 144.0;
    } else {
      // Cubic Meters = (L_cm * W_cm * T_cm) / 1,000,000
      volPerPiece = (L * W * T) / 1000000;
    }
    
    const totalVol = volPerPiece * Q;

    return {
      volumePerPiece: volPerPiece,
      totalVolume: totalVol,
    };
  }, [length, width, thickness, quantity, isImperial]);

  return (
    <Card>
      <h2 className="text-2xl font-bold text-slate-100 mb-1">Lumber Volume Calculator</h2>
      <p className="text-slate-400 mb-6">
        {isImperial 
         ? "Calculate board feet. A board foot is 1ft × 1ft × 1in (144 cubic inches)."
         : "Calculate lumber volume in cubic meters."
        }
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Input label={`Length (${unitLabel})`} type="number" value={length} onChange={(e) => setLength(e.target.value)} />
        <Input label={`Width (${unitLabel})`} type="number" value={width} onChange={(e) => setWidth(e.target.value)} />
        <Input label={`Thickness (${unitLabel})`} type="number" value={thickness} onChange={(e) => setThickness(e.target.value)} />
        <Input label="Quantity" type="number" value={quantity} onChange={(e) => setQuantity(e.target.value)} step="1" min="1" />
      </div>

      {error ? (
        <div className="mt-6 p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-lg">
          <p>{error}</p>
        </div>
      ) : (
        <div className="mt-6 p-6 bg-slate-900/50 border border-slate-700 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-center">
                <div>
                    <p className="text-sm text-rose-400 font-medium">{volumeUnit} per Piece</p>
                    <p className="text-3xl font-bold text-slate-100">{volumePerPiece?.toFixed(3)}</p>
                </div>
                 <div>
                    <p className="text-sm text-rose-400 font-medium">Total {volumeUnit}</p>
                    <p className="text-3xl font-bold text-slate-100">{totalVolume?.toFixed(3)}</p>
                </div>
            </div>
        </div>
      )}
    </Card>
  );
};

export default LumberVolumeCalculator;