import React, { useState, useMemo } from 'react';
import Card from './common/Card.tsx';
import Input from './common/Input.tsx';
import { useSettings } from '../contexts/SettingsContext.tsx';

const ArcCalculator: React.FC = () => {
  const { unitSystem } = useSettings();
  const unitLabel = unitSystem === 'imperial' ? 'in' : 'cm';

  const [span, setSpan] = useState('48');
  const [rise, setRise] = useState('8');
  const [segments, setSegments] = useState('6');

  const { radius, segmentLength, miterAngle, totalAngle, error } = useMemo(() => {
    const W = parseFloat(span);
    const H = parseFloat(rise);
    const N = parseInt(segments, 10);

    if (isNaN(W) || isNaN(H) || isNaN(N) || W <= 0 || H <= 0 || N <= 1 || H >= W/2) {
      return { error: 'Please enter valid numbers. Span must be greater than rise*2.' };
    }

    const R = (W * W) / (8 * H) + H / 2;
    const alpha = 2 * Math.asin(W / (2 * R)); // Total angle in radians
    const segmentAngle = alpha / N;
    const miterAngleRad = segmentAngle / 2;
    const segLength = 2 * R * Math.sin(miterAngleRad);

    return {
      radius: R,
      segmentLength: segLength,
      miterAngle: miterAngleRad * (180 / Math.PI), // Convert to degrees
      totalAngle: alpha * (180 / Math.PI),
    };
  }, [span, rise, segments]);

  const ArcDiagram: React.FC<{
    span: number;
    rise: number;
    radius: number;
    segments: number;
    totalAngle: number;
  }> = ({ span, rise, radius, segments, totalAngle }) => {
    if (isNaN(radius)) return null;
    
    const viewBoxSize = 1000;
    const scale = viewBoxSize / span * 0.9;
    const pathRadius = radius * scale;
    const pathSpan = span * scale;
    const pathRise = rise * scale;

    const startX = (viewBoxSize - pathSpan) / 2;
    const endX = startX + pathSpan;
    const midY = viewBoxSize/2 - pathRise/2;
    
    const cx = viewBoxSize/2;
    const cy = midY - (pathRadius-pathRise);

    const segmentPoints = [];
    const angleStep = (totalAngle * (Math.PI / 180)) / segments;
    const startAngle = -Math.PI/2 - (totalAngle * (Math.PI / 180))/2;

    for (let i = 0; i <= segments; i++) {
        const angle = startAngle + i * angleStep;
        segmentPoints.push({
            x: cx + pathRadius * Math.cos(angle),
            y: cy + pathRadius * Math.sin(angle),
        });
    }

    return (
        <div className="w-full aspect-video bg-slate-900 border border-slate-700 rounded-lg mt-6 p-4 flex items-center justify-center">
            <svg viewBox={`0 0 ${viewBoxSize} ${viewBoxSize/2}`} className="w-full h-full">
                <path
                    d={`M ${startX} ${midY} A ${pathRadius} ${pathRadius} 0 0 1 ${endX} ${midY}`}
                    stroke="#f43f5e"
                    strokeWidth="2"
                    fill="none"
                    strokeDasharray="4"
                />
                {segmentPoints.map((p, i) => i > 0 && (
                    <line key={i} x1={segmentPoints[i-1].x} y1={segmentPoints[i-1].y} x2={p.x} y2={p.y} stroke="#e2e8f0" strokeWidth="3" />
                ))}
            </svg>
        </div>
    );
  };
  
  const ResultDisplay: React.FC<{label: string, value: string, unit: string}> = ({label, value, unit}) => (
      <div className="text-center">
          <p className="text-sm text-rose-400 font-medium">{label}</p>
          <p className="text-xl font-bold text-slate-100">{value} <span className="text-base font-normal text-slate-400">{unit}</span></p>
      </div>
  );

  return (
    <Card>
      <h2 className="text-2xl font-bold text-slate-100 mb-1">Arc Segment Calculator</h2>
      <p className="text-slate-400 mb-6">Calculate the dimensions and angles needed to create a curved arch from straight segments.</p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Input label={`Total Span (W) (${unitLabel})`} type="number" value={span} onChange={(e) => setSpan(e.target.value)} placeholder="e.g., 48" />
        <Input label={`Total Rise (H) (${unitLabel})`} type="number" value={rise} onChange={(e) => setRise(e.target.value)} placeholder="e.g., 8" />
        <Input label="Number of Segments (N)" type="number" value={segments} onChange={(e) => setSegments(e.target.value)} placeholder="e.g., 6" step="1" min="2" />
      </div>

      {error ? (
        <div className="mt-6 p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-lg">
          <p>{error}</p>
        </div>
      ) : (
        <div className="mt-6 p-6 bg-slate-900/50 border border-slate-700 rounded-lg">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-3">
                <ResultDisplay label="Radius" value={radius?.toFixed(3) ?? '0'} unit={unitLabel} />
                <ResultDisplay label="Segment Length" value={segmentLength?.toFixed(3) ?? '0'} unit={unitLabel} />
                <ResultDisplay label="Miter Angle" value={miterAngle?.toFixed(3) ?? '0'} unit="°" />
                <ResultDisplay label="Total Angle" value={totalAngle?.toFixed(3) ?? '0'} unit="°" />
            </div>
             {!isNaN(parseFloat(span)) && !isNaN(parseFloat(rise)) && radius && totalAngle && (
                <ArcDiagram span={parseFloat(span)} rise={parseFloat(rise)} radius={radius} segments={parseInt(segments)} totalAngle={totalAngle} />
            )}
        </div>
      )}
    </Card>
  );
};

export default ArcCalculator;