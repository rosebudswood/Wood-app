import React from 'react';
import { View } from '../types.ts';
import { ICONS } from '../constants.tsx';

interface DashboardProps {
  setActiveView: (view: View) => void;
}

const features = [
    { view: View.GETTING_STARTED, title: 'Getting Started', description: 'Begin your woodworking journey with essential steps and tools.', icon: ICONS.GETTING_STARTED },
    { view: View.PROJECT_PLANNER, title: 'Project Planner', description: 'Plan your projects, from materials and steps to the final cut list.', icon: ICONS.PROJECT_PLANNER },
    { view: View.TOOL_INVENTORY, title: 'Tool Inventory', description: 'Keep a digital catalog of all the tools in your workshop.', icon: ICONS.TOOL_INVENTORY },
    { view: View.TIPS, title: 'AI Woodworking Tips', description: 'Get helpful, AI-powered tips for beginners and experts alike.', icon: ICONS.TIPS },
    { view: View.WOOD_SELECTOR, title: 'AI Wood Selector', description: 'Let AI suggest the perfect wood for your project based on your region.', icon: ICONS.WOOD_SELECTOR },
    { view: View.FINISHING_GUIDE, title: 'AI Finishing Guide', description: 'Find the ideal finish for your creation with smart suggestions.', icon: ICONS.FINISHING_GUIDE },
    { view: View.CUT_LIST, title: 'Cut List', description: 'Organize the pieces and dimensions you need for a project.', icon: ICONS.CUT_LIST },
    { view: View.PRICING_GUIDE, title: 'Pricing Guide', description: 'Accurately price your work with this handy worksheet.', icon: ICONS.PRICING_GUIDE },
    { view: View.ARC_CALCULATOR, title: 'Arc Calculator', description: 'Calculate segments for creating perfect curved arches.', icon: ICONS.ARC_CALCULATOR },
    { view: View.LUMBER_VOLUME_CALCULATOR, title: 'Lumber Volume', description: 'Quickly calculate board feet or cubic meters for your lumber.', icon: ICONS.LUMBER_VOLUME_CALCULATOR },
];

const FeatureCard: React.FC<{
  title: string;
  description: string;
  icon: React.ReactElement<React.SVGProps<SVGSVGElement>>;
  onClick: () => void;
}> = ({ title, description, icon, onClick }) => (
    <div
        onClick={onClick}
        className="bg-slate-800/50 rounded-xl shadow-lg border border-slate-700/50 p-6 flex flex-col items-start hover:bg-slate-800 hover:border-rose-500/50 transition-all duration-200 cursor-pointer"
        role="button"
        tabIndex={0}
        onKeyPress={(e) => (e.key === 'Enter' || e.key === ' ') && onClick()}
    >
        <div className="w-12 h-12 bg-rose-900/50 rounded-lg flex items-center justify-center mb-4 border border-rose-800 text-rose-400">
            {React.cloneElement(icon, { className: "h-7 w-7", "aria-hidden": "true" })}
        </div>
        <h3 className="text-lg font-bold text-slate-100 mb-2">{title}</h3>
        <p className="text-sm text-slate-400 leading-relaxed">{description}</p>
    </div>
);


const Dashboard: React.FC<DashboardProps> = ({ setActiveView }) => {
  return (
    <div>
      <h1 className="text-3xl font-bold text-slate-100 mb-2">Welcome to your Workshop</h1>
      <p className="text-slate-400 mb-8">Your all-in-one assistant for every step of the woodworking process. Select a tool or guide to get started.</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map(feature => (
          <FeatureCard
            key={feature.view}
            title={feature.title}
            description={feature.description}
            icon={feature.icon}
            onClick={() => setActiveView(feature.view)}
          />
        ))}
      </div>
    </div>
  );
};

export default Dashboard;