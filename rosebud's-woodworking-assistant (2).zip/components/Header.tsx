import React from 'react';
import { ROSEBUDS_LOGO } from '../constants.tsx';
import { useSettings } from '../contexts/SettingsContext.tsx';
import { UnitSystem, Currency, CURRENCY_SYMBOLS } from '../types.ts';

const UnitToggle: React.FC<{
    unitSystem: UnitSystem;
    setUnitSystem: (system: UnitSystem) => void;
}> = ({ unitSystem, setUnitSystem }) => {
    const baseClasses = "px-3 py-1 text-sm font-medium rounded-md transition-colors";
    const activeClasses = "bg-rose-600 text-white";
    const inactiveClasses = "bg-slate-700 text-slate-300 hover:bg-slate-600";

    return (
        <div className="flex items-center p-1 bg-slate-800 rounded-lg">
            <button onClick={() => setUnitSystem('imperial')} className={`${baseClasses} ${unitSystem === 'imperial' ? activeClasses : inactiveClasses}`}>
                Imperial
            </button>
            <button onClick={() => setUnitSystem('metric')} className={`${baseClasses} ${unitSystem === 'metric' ? activeClasses : inactiveClasses}`}>
                Metric
            </button>
        </div>
    )
};

const CurrencySelector: React.FC<{
    currency: Currency;
    setCurrency: (currency: Currency) => void;
}> = ({ currency, setCurrency }) => {
    return (
        <div className="relative">
            <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as Currency)}
                className="appearance-none w-full bg-slate-800 border border-slate-700 text-white text-sm font-medium py-1.5 pl-3 pr-8 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
            >
                {(Object.keys(CURRENCY_SYMBOLS) as Currency[]).map(c => (
                    <option key={c} value={c}>{c} ({CURRENCY_SYMBOLS[c]})</option>
                ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-400">
                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
            </div>
        </div>
    );
};

const Header: React.FC = () => {
  const { unitSystem, setUnitSystem, currency, setCurrency } = useSettings();

  return (
    <header className="bg-slate-800/50 shadow-lg border-b border-slate-700/50 print:hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
            <div className="flex items-center space-x-4">
                <ROSEBUDS_LOGO />
                <h1 className="text-2xl font-bold text-slate-100 tracking-tight">Rosebud's Woodworking Assistant</h1>
            </div>
            <div className="flex items-center space-x-4">
                <CurrencySelector currency={currency} setCurrency={setCurrency} />
                <UnitToggle unitSystem={unitSystem} setUnitSystem={setUnitSystem} />
            </div>
        </div>
      </div>
    </header>
  );
};

export default Header;