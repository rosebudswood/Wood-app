import React, { useState, useCallback } from 'react';
import { getFinishSuggestions } from '../services/geminiService.ts';
import { FinishSuggestion } from '../types.ts';
import Card from './common/Card.tsx';
import Input from './common/Input.tsx';
import Button from './common/Button.tsx';
import LoadingSpinner from './common/LoadingSpinner.tsx';

const FinishingGuide: React.FC = () => {
  const [project, setProject] = useState('');
  const [suggestions, setSuggestions] = useState<FinishSuggestion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchSuggestions = useCallback(async () => {
    if (!project) {
      setError('Please describe your project.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setSuggestions([]);
    try {
      const result = await getFinishSuggestions(project);
      setSuggestions(result);
    } catch (err) {
      setError('Sorry, I had trouble getting suggestions. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [project]);

  const SuggestionCard: React.FC<{ suggestion: FinishSuggestion }> = ({ suggestion }) => (
    <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700/50">
        <div className="flex justify-between items-start">
            <h3 className="text-lg font-bold text-rose-400">{suggestion.finish}</h3>
            <span className="text-xs font-semibold bg-rose-900/50 text-rose-300 px-2 py-1 rounded-full">{suggestion.type}</span>
        </div>
        <p className="text-slate-400 mt-1 mb-3 text-sm">{suggestion.reason}</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
            <div>
                <h4 className="font-semibold text-green-400">Pros</h4>
                <ul className="list-disc list-inside text-sm text-slate-300 space-y-1">
                    {suggestion.pros.map((pro, i) => <li key={i}>{pro}</li>)}
                </ul>
            </div>
            <div>
                <h4 className="font-semibold text-red-400">Cons</h4>
                <ul className="list-disc list-inside text-sm text-slate-300 space-y-1">
                    {suggestion.cons.map((con, i) => <li key={i}>{con}</li>)}
                </ul>
            </div>
        </div>
         <div>
            <h4 className="font-semibold text-slate-300">Application</h4>
            <p className="text-sm text-slate-400">{suggestion.application}</p>
        </div>
    </div>
  );

  return (
    <Card>
      <h2 className="text-2xl font-bold text-slate-100 mb-1">AI Finishing Guide</h2>
      <p className="text-slate-400 mb-6">Describe your project (e.g., "outdoor cedar bench", "maple cutting board") and I'll suggest the best finishes.</p>
      
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="flex-grow">
          <Input
            label="What are you finishing?"
            id="project-description"
            value={project}
            onChange={(e) => setProject(e.target.value)}
            placeholder="e.g., An indoor oak coffee table"
          />
        </div>
        <Button onClick={fetchSuggestions} disabled={isLoading} className="sm:mt-auto h-10">
          {isLoading ? 'Thinking...' : 'Get Suggestions'}
        </Button>
      </div>

      {error && <p className="text-red-400 mt-4">{error}</p>}
      
      <div className="mt-8">
        {isLoading && <LoadingSpinner />}
        {suggestions.length > 0 && (
          <div className="space-y-4">
            {suggestions.map((s, i) => <SuggestionCard key={i} suggestion={s} />)}
          </div>
        )}
      </div>
    </Card>
  );
};

export default FinishingGuide;