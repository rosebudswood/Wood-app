import React from 'react';
import { View } from '../types.ts';
import { ICONS } from '../constants.tsx';

interface NavigationProps {
  activeView: View;
  setActiveView: (view: View) => void;
}

const NavButton: React.FC<{
  label: string;
  icon: React.ReactNode;
  isActive: boolean;
  onClick: () => void;
}> = ({ label, icon, isActive, onClick }) => {
  const activeClasses = 'bg-rose-900/50 text-rose-300 border-rose-500';
  const inactiveClasses = 'text-slate-400 hover:bg-slate-700/50 hover:text-slate-200 border-transparent';

  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center px-4 py-3 text-left text-base font-medium rounded-lg border-l-4 transition-colors duration-150 ${
        isActive ? activeClasses : inactiveClasses
      }`}
    >
      {icon}
      {label}
    </button>
  );
};

const NavSection: React.FC<{
  title: string;
  items: { view: View; label: string; icon: React.ReactNode }[];
  activeView: View;
  setActiveView: (view: View) => void;
}> = ({ title, items, activeView, setActiveView }) => (
    <div>
        <h3 className="px-4 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">{title}</h3>
        {items.map((item) => (
          <NavButton
            key={item.view}
            label={item.label}
            icon={item.icon}
            isActive={activeView === item.view}
            onClick={() => setActiveView(item.view)}
          />
        ))}
    </div>
);


const Navigation: React.FC<NavigationProps> = ({ activeView, setActiveView }) => {
  const mainItems = [
    { view: View.DASHBOARD, label: "Dashboard", icon: ICONS.DASHBOARD },
    { view: View.GETTING_STARTED, label: "Getting Started", icon: ICONS.GETTING_STARTED },
  ];
  
  const aiGuides = [
    { view: View.TIPS, label: "AI Woodworking Tips", icon: ICONS.TIPS },
    { view: View.WOOD_SELECTOR, label: "AI Wood Selector", icon: ICONS.WOOD_SELECTOR },
    { view: View.FINISHING_GUIDE, label: "AI Finishing Guide", icon: ICONS.FINISHING_GUIDE },
    { view: View.AI_CHAT, label: "AI Troubleshooter", icon: ICONS.AI_CHAT },
  ];
  
  const toolsAndCalculators = [
    { view: View.CUT_LIST, label: "Cut List", icon: ICONS.CUT_LIST },
    { view: View.ARC_CALCULATOR, label: "Arc Calculator", icon: ICONS.ARC_CALCULATOR },
    { view: View.LUMBER_VOLUME_CALCULATOR, label: "Lumber Volume", icon: ICONS.LUMBER_VOLUME_CALCULATOR },
  ];

  const managementItems = [
    { view: View.PROJECT_PLANNER, label: "Project Planner", icon: ICONS.PROJECT_PLANNER },
    { view: View.TOOL_INVENTORY, label: "Tool Inventory", icon: ICONS.TOOL_INVENTORY },
    { view: View.PRICING_GUIDE, label: "Pricing Guide", icon: ICONS.PRICING_GUIDE },
  ];

  return (
    <nav className="space-y-6 bg-slate-800/50 p-4 rounded-xl shadow-lg border border-slate-700/50">
      <NavSection title="Start" items={mainItems} activeView={activeView} setActiveView={setActiveView} />
      <NavSection title="AI Guides" items={aiGuides} activeView={activeView} setActiveView={setActiveView} />
      <NavSection title="Tools & Calculators" items={toolsAndCalculators} activeView={activeView} setActiveView={setActiveView} />
      <NavSection title="Management" items={managementItems} activeView={activeView} setActiveView={setActiveView} />
    </nav>
  );
};

export default Navigation;