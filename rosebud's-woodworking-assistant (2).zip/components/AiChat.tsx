import React, { useState, useEffect, useRef } from 'react';
import { createChatSession } from '../services/geminiService.ts';
import { ChatMessage } from '../types.ts';
import Card from './common/Card.tsx';
import Input from './common/Input.tsx';
import Button from './common/Button.tsx';
import LoadingSpinner from './common/LoadingSpinner.tsx';
import { Chat } from '@google/genai';

const AiChat: React.FC = () => {
    const [chat, setChat] = useState<Chat | null>(null);
    const [history, setHistory] = useState<ChatMessage[]>([]);
    const [userInput, setUserInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const chatContainerRef = useRef<HTMLDivElement>(null);
    
    useEffect(() => {
        try {
            const session = createChatSession();
            setChat(session);
        } catch (e: any) {
            setError(e.message || "Failed to initialize chat session.");
        }
    }, []);

    useEffect(() => {
        if (chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
    }, [history]);

    const handleSendMessage = async () => {
        if (!userInput.trim() || !chat || isLoading) return;

        const userMessage: ChatMessage = { role: 'user', text: userInput };
        setHistory(prev => [...prev, userMessage]);
        setUserInput('');
        setIsLoading(true);
        setError(null);
        
        try {
            const stream = await chat.sendMessageStream({ message: userInput });
            let modelResponse = '';
            setHistory(prev => [...prev, { role: 'model', text: '' }]);

            for await (const chunk of stream) {
                modelResponse += chunk.text;
                setHistory(prev => {
                    const newHistory = [...prev];
                    newHistory[newHistory.length - 1].text = modelResponse;
                    return newHistory;
                });
            }
        } catch (e) {
            console.error(e);
            setError('An error occurred while getting a response. Please try again.');
            setHistory(prev => [...prev, { role: 'model', text: 'Sorry, I ran into an error.'}]);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Card>
            <h2 className="text-2xl font-bold text-slate-100 mb-1">AI Troubleshooter</h2>
            <p className="text-slate-400 mb-6">Ask me anything about woodworking, from safety tips to finishing techniques.</p>

            <div className="bg-slate-900/50 border border-slate-700/50 rounded-lg h-[60vh] flex flex-col p-4">
                <div ref={chatContainerRef} className="flex-grow overflow-y-auto space-y-4 pr-2">
                    {history.length === 0 && !error && (
                        <div className="flex justify-center items-center h-full text-slate-500">
                            <p>Ask a question to start the conversation.</p>
                        </div>
                    )}
                     {error && (
                        <div className="flex justify-center items-center h-full text-red-400">
                            <p>{error}</p>
                        </div>
                    )}
                    {history.map((msg, index) => (
                        <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-xl px-4 py-2 rounded-xl ${msg.role === 'user' ? 'bg-rose-600 text-white' : 'bg-slate-700 text-slate-200'}`}>
                                <p className="whitespace-pre-wrap">{msg.text}</p>
                            </div>
                        </div>
                    ))}
                    {isLoading && history[history.length - 1]?.role === 'user' && (
                         <div className="flex justify-start">
                            <div className="max-w-xl px-4 py-2 rounded-xl bg-slate-700 text-slate-200">
                               <LoadingSpinner />
                            </div>
                        </div>
                    )}
                </div>
                <div className="mt-4 flex gap-2">
                    <Input 
                        label="" 
                        id="chat-input" 
                        value={userInput} 
                        onChange={e => setUserInput(e.target.value)} 
                        onKeyPress={e => e.key === 'Enter' && handleSendMessage()}
                        placeholder="Type your question here..."
                        disabled={isLoading || !!error}
                    />
                    <Button onClick={handleSendMessage} disabled={isLoading || !userInput.trim() || !!error}>Send</Button>
                </div>
            </div>
        </Card>
    );
};

export default AiChat;