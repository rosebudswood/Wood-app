import React, { useState, useEffect, useCallback } from 'react';
import { getGettingStartedContent } from '../services/geminiService.ts';
import { GettingStartedContent, GettingStartedStep, EssentialTool } from '../types.ts';
import Card from './common/Card.tsx';
import LoadingSpinner from './common/LoadingSpinner.tsx';
import Button from './common/Button.tsx';

const GettingStarted: React.FC = () => {
    const [content, setContent] = useState<GettingStartedContent | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchContent = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        try {
            const result = await getGettingStartedContent();
            setContent(result);
        } catch (err) {
            setError('Sorry, I had trouble getting the getting started guide. Please try again.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchContent();
    }, [fetchContent]);

    const renderContent = () => {
        if (isLoading) return <LoadingSpinner />;
        if (error) return (
            <div className="text-center text-red-400">
                <p>{error}</p>
                <Button onClick={fetchContent} className="mt-4">Try Again</Button>
            </div>
        );
        if (!content) return <p className="text-slate-400">No content available.</p>;

        return (
            <div className="space-y-8">
                <div>
                    <h3 className="text-xl font-bold text-rose-400 mb-4 border-b-2 border-rose-500/30 pb-2">First Steps to Take</h3>
                    <div className="space-y-6">
                        {content.firstSteps.map((step: GettingStartedStep, index: number) => (
                            <div key={index} className="flex items-start space-x-4">
                                <div className="flex-shrink-0 h-8 w-8 rounded-full bg-rose-500 flex items-center justify-center font-bold text-white">
                                    {index + 1}
                                </div>
                                <div>
                                    <h4 className="font-bold text-slate-200">{step.title}</h4>
                                    <p className="text-slate-400">{step.description}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
                <div>
                    <h3 className="text-xl font-bold text-rose-400 mb-4 border-b-2 border-rose-500/30 pb-2">Essential Tools for Beginners</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {content.essentialTools.map((tool: EssentialTool, index: number) => (
                            <div key={index} className="bg-slate-800/70 p-4 rounded-lg border border-slate-700/50">
                                <div className="flex justify-between items-start mb-1">
                                    <h4 className="font-bold text-slate-200">{tool.tool}</h4>
                                    <span className="text-xs font-semibold bg-slate-700 text-slate-300 px-2 py-1 rounded-full">{tool.type}</span>
                                </div>
                                <p className="text-slate-400 text-sm">{tool.description}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        );
    }

    return (
        <Card>
            <h2 className="text-2xl font-bold text-slate-100 mb-1">Getting Started in Woodworking</h2>
            <p className="text-slate-400 mb-6">Welcome! Here are some fundamental steps and tools to begin your woodworking journey.</p>
            {renderContent()}
        </Card>
    );
};

export default GettingStarted;