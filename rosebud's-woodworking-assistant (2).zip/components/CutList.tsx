import React, { useState, useCallback } from 'react';
import { CutListItem } from '../types.ts';
import Card from './common/Card.tsx';
import Input from './common/Input.tsx';
import Button from './common/Button.tsx';
import { useSettings } from '../contexts/SettingsContext.tsx';

const CutList: React.FC = () => {
  const { unitSystem } = useSettings();
  const unitLabel = unitSystem === 'imperial' ? 'in' : 'cm';

  const [items, setItems] = useState<CutListItem[]>([]);
  const [newItem, setNewItem] = useState({ part: '', length: '', width: '', thickness: '', quantity: 1 });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewItem(prev => ({ ...prev, [name]: name === 'quantity' ? parseInt(value, 10) : value }));
  };

  const addItem = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (!newItem.part || !newItem.length || !newItem.width || !newItem.thickness) return;
    setItems(prev => [...prev, { ...newItem, id: Date.now() }]);
    setNewItem({ part: '', length: '', width: '', thickness: '', quantity: 1 });
  }, [newItem]);

  const deleteItem = (id: number) => {
    setItems(prev => prev.filter(item => item.id !== id));
  };

  return (
    <Card>
      <h2 className="text-2xl font-bold text-slate-100 mb-1">Project Cut List</h2>
      <p className="text-slate-400 mb-6">Organize all the pieces you need for your project. Dimensions will use the selected unit system.</p>

      <form onSubmit={addItem} className="p-4 bg-slate-800 border border-slate-700 rounded-lg mb-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="col-span-2 lg:col-span-4">
            <Input label="Part Name" name="part" value={newItem.part} onChange={handleInputChange} placeholder="e.g., Table Leg" />
          </div>
          <Input label={`Length (${unitLabel})`} name="length" value={newItem.length} onChange={handleInputChange} placeholder="e.g., 29" type="number" />
          <Input label={`Width (${unitLabel})`} name="width" value={newItem.width} onChange={handleInputChange} placeholder="e.g., 3.5" type="number" />
          <Input label={`Thickness (${unitLabel})`} name="thickness" value={newItem.thickness} onChange={handleInputChange} placeholder="e.g., 1.5" type="number" />
          <Input label="Quantity" name="quantity" type="number" value={newItem.quantity} onChange={handleInputChange} min="1" />
           <div className="col-span-2 lg:col-span-4">
              <Button type="submit" variant="primary" className="w-full">Add to List</Button>
           </div>
        </div>
      </form>

      <div className="overflow-x-auto bg-slate-900/50 rounded-lg border border-slate-700/50">
        <table className="min-w-full divide-y divide-slate-700">
          <thead className="bg-slate-800">
            <tr>
              {['Part', 'Qty', `Length (${unitLabel})`, `Width (${unitLabel})`, `Thickness (${unitLabel})`, 'Actions'].map(header => (
                <th key={header} className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">{header}</th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-slate-800/50 divide-y divide-slate-700">
            {items.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-12 text-center text-slate-400">Your cut list is empty. Add a part to get started.</td>
              </tr>
            )}
            {items.map(item => (
              <tr key={item.id} className="hover:bg-slate-700/50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-200">{item.part}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-300">{item.quantity}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-300">{item.length}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-300">{item.width}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-300">{item.thickness}</td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button onClick={() => deleteItem(item.id)} className="text-rose-500 hover:text-rose-400">
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
};

export default CutList;