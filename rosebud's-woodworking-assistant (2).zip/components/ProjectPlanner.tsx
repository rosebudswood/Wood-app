import React, { useState, useMemo } from 'react';
import { Project, ProjectStep, ProjectMaterial, CutListItem, ProjectScaffold } from '../types.ts';
import useLocalStorage from '../hooks/useLocalStorage.ts';
import { useSettings } from '../contexts/SettingsContext.tsx';
import { useToast } from '../contexts/ToastContext.tsx';
import { generateProjectScaffold } from '../services/geminiService.ts';
import Card from './common/Card.tsx';
import Input from './common/Input.tsx';
import Button from './common/Button.tsx';
import Modal from './common/Modal.tsx';
import LoadingSpinner from './common/LoadingSpinner.tsx';


const ProjectPlanner: React.FC = () => {
    const [projects, setProjects] = useLocalStorage<Project[]>('rosebud-projects', []);
    const [selectedProject, setSelectedProject] = useState<Project | null>(null);
    const [isAiModalOpen, setIsAiModalOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const { addToast } = useToast();
    const { unitSystem } = useSettings();
    const unitLabel = unitSystem === 'imperial' ? 'in' : 'cm';

    const filteredProjects = useMemo(() => {
        return projects.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
    }, [projects, searchTerm]);

    const updateProject = (updatedProject: Project) => {
        setProjects(prev => prev.map(p => p.id === updatedProject.id ? updatedProject : p));
        setSelectedProject(updatedProject);
    };

    const handleCreateProject = () => {
        const newProject: Project = { id: Date.now(), name: 'New Project', description: '', status: 'Planning', materials: [], steps: [], cutListItems: [] };
        setProjects(prev => [...prev, newProject]);
        setSelectedProject(newProject);
        addToast('New project created!', 'success');
    };

    const handleDeleteProject = (id: number) => {
        setProjects(prev => prev.filter(p => p.id !== id));
        setSelectedProject(null);
        addToast('Project deleted.', 'info');
    };
    
    const handleExport = () => {
        const dataStr = JSON.stringify(projects, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
        const exportFileDefaultName = 'rosebud_projects_export.json';
        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
        addToast('Project data exported.', 'success');
    };

    const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
        const fileReader = new FileReader();
        if (event.target.files && event.target.files[0]) {
            fileReader.readAsText(event.target.files[0], "UTF-8");
            fileReader.onload = e => {
                try {
                    const imported: Project[] = JSON.parse(e.target?.result as string);
                    if (Array.isArray(imported) && imported.every(p => 'id' in p && 'name' in p && 'status' in p)) {
                        setProjects(imported);
                        addToast('Projects imported successfully!', 'success');
                    } else {
                        addToast('Invalid project file format.', 'error');
                    }
                } catch (err) {
                    addToast('Failed to parse import file.', 'error');
                }
            };
        }
    };


    if (selectedProject) {
        return <ProjectDetailView project={selectedProject} updateProject={updateProject} onBack={() => setSelectedProject(null)} deleteProject={handleDeleteProject} unitLabel={unitLabel} />;
    }

    return (
        <Card>
            <div className="flex flex-wrap justify-between items-start gap-4 mb-6">
                <div>
                    <h2 className="text-2xl font-bold text-slate-100 mb-1">Project Planner</h2>
                    <p className="text-slate-400">Manage all your woodworking projects in one place.</p>
                </div>
                <div className="flex gap-2 flex-wrap">
                    <Button onClick={() => setIsAiModalOpen(true)} variant="secondary">Create with AI</Button>
                    <Button onClick={handleCreateProject}>Create New Project</Button>
                </div>
            </div>
             <div className="flex flex-wrap gap-4 mb-4">
                <div className="flex-grow"><Input label="" id="search-projects" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Search projects..."/></div>
                <div className="flex gap-2">
                    <Button onClick={handleExport} variant="secondary">Export</Button>
                    <label className="px-4 py-2 font-semibold rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 bg-slate-700 text-slate-200 hover:bg-slate-600 focus:ring-slate-500 cursor-pointer">
                        Import
                        <input type="file" className="hidden" accept=".json" onChange={handleImport} />
                    </label>
                </div>
            </div>
            <div className="space-y-4">
                {filteredProjects.length === 0 && <p className="text-center py-8 text-slate-400">No projects found.</p>}
                {filteredProjects.map(p => (
                    <div key={p.id} onClick={() => setSelectedProject(p)} className="bg-slate-800/70 p-4 rounded-lg border border-slate-700/50 flex justify-between items-center cursor-pointer hover:bg-slate-800">
                        <div>
                            <h3 className="font-bold text-slate-200">{p.name}</h3>
                            <p className="text-sm text-slate-400">{p.description || 'No description'}</p>
                        </div>
                        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${p.status === 'Completed' ? 'bg-green-900/50 text-green-300' : 'bg-blue-900/50 text-blue-300'}`}>{p.status}</span>
                    </div>
                ))}
            </div>
            <AiProjectModal 
                isOpen={isAiModalOpen} 
                onClose={() => setIsAiModalOpen(false)}
                onProjectCreated={(scaffold) => {
                    const newProject: Project = {
                        id: Date.now(),
                        name: scaffold.name,
                        description: scaffold.description,
                        status: 'Planning',
                        materials: scaffold.materials.map((m, i) => ({...m, id: i})),
                        steps: scaffold.steps.map((s, i) => ({id: i, description: s, isCompleted: false})),
                        cutListItems: [],
                    };
                    setProjects(prev => [...prev, newProject]);
                    setSelectedProject(newProject);
                }}
            />
        </Card>
    );
};

const ProjectDetailView: React.FC<{ project: Project, updateProject: (p: Project) => void, onBack: () => void, deleteProject: (id: number) => void, unitLabel: string }> = ({ project, updateProject, onBack, deleteProject, unitLabel }) => {
    const { addToast } = useToast();
    const [name, setName] = useState(project.name);
    const [description, setDescription] = useState(project.description);

    const handleUpdateDetails = () => {
        updateProject({ ...project, name, description });
        addToast('Details updated!', 'success');
    };
    
    // Step Management
    const [newStep, setNewStep] = useState('');
    const addStep = () => {
        if (!newStep.trim()) return;
        const step: ProjectStep = { id: Date.now(), description: newStep, isCompleted: false };
        updateProject({ ...project, steps: [...project.steps, step] });
        setNewStep('');
    };
    const toggleStep = (id: number) => {
        const steps = project.steps.map(s => s.id === id ? { ...s, isCompleted: !s.isCompleted } : s);
        updateProject({ ...project, steps });
    };
    const deleteStep = (id: number) => {
        const steps = project.steps.filter(s => s.id !== id);
        updateProject({ ...project, steps });
    }

    // Material Management
    const [newMaterial, setNewMaterial] = useState({ item: '', quantity: '' });
    const addMaterial = () => {
        if (!newMaterial.item.trim() || !newMaterial.quantity.trim()) return;
        const material: ProjectMaterial = { ...newMaterial, id: Date.now() };
        updateProject({ ...project, materials: [...project.materials, material] });
        setNewMaterial({ item: '', quantity: '' });
    };
     const deleteMaterial = (id: number) => {
        const materials = project.materials.filter(m => m.id !== id);
        updateProject({ ...project, materials });
    }

    // Cut List Management
    const [newCutListItem, setNewCutListItem] = useState({ part: '', length: '', width: '', thickness: '', quantity: 1 });
    const addCutListItem = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newCutListItem.part || !newCutListItem.length || !newCutListItem.width || !newCutListItem.thickness) return;
        const item: CutListItem = { ...newCutListItem, id: Date.now(), quantity: Number(newCutListItem.quantity) };
        updateProject({ ...project, cutListItems: [...project.cutListItems, item] });
        setNewCutListItem({ part: '', length: '', width: '', thickness: '', quantity: 1 });
    };
    const deleteCutListItem = (id: number) => {
        const cutListItems = project.cutListItems.filter(i => i.id !== id);
        updateProject({ ...project, cutListItems });
    };
    
    return (
        <div className="space-y-8">
            <Card>
                <div className="flex justify-between items-center mb-4">
                    <Button onClick={onBack} variant="secondary">← Back to Projects</Button>
                    <div className="flex items-center gap-4">
                        <select value={project.status} onChange={e => updateProject({...project, status: e.target.value as Project['status']})} className="bg-slate-900 border border-slate-600 rounded-md p-2 text-white h-10">
                            <option>Planning</option>
                            <option>In Progress</option>
                            <option>Completed</option>
                        </select>
                        <Button onClick={() => deleteProject(project.id)} variant="secondary" className="!bg-red-900/50 hover:!bg-red-800/50 text-red-300">Delete Project</Button>
                    </div>
                </div>

                <h2 className="text-2xl font-bold text-slate-100">Project Details</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <Input label="Project Name" value={name} onChange={e => setName(e.target.value)} onBlur={handleUpdateDetails} />
                    <Input label="Description" value={description} onChange={e => setDescription(e.target.value)} onBlur={handleUpdateDetails} />
                </div>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <Card>
                    <h3 className="text-xl font-bold text-rose-400 mb-4">Materials</h3>
                    <div className="space-y-2 mb-4 max-h-60 overflow-y-auto pr-2">
                        {project.materials.length === 0 && <p className="text-slate-500 text-sm">No materials added yet.</p>}
                        {project.materials.map(m => <div key={m.id} className="flex justify-between items-center bg-slate-800 p-2 rounded"><span>{m.item}</span><span className="text-slate-400">{m.quantity}</span><button onClick={() => deleteMaterial(m.id)} className="text-xs text-slate-500 hover:text-white">X</button></div>)}
                    </div>
                    <div className="flex gap-2">
                        <Input label="" placeholder="Material Name" value={newMaterial.item} onChange={e => setNewMaterial(p => ({...p, item: e.target.value}))}/>
                        <Input label="" placeholder="Quantity" value={newMaterial.quantity} onChange={e => setNewMaterial(p => ({...p, quantity: e.target.value}))}/>
                        <Button onClick={addMaterial} className="mt-auto h-10">Add</Button>
                    </div>
                </Card>
                <Card>
                    <h3 className="text-xl font-bold text-rose-400 mb-4">Steps</h3>
                    <div className="space-y-2 mb-4 max-h-60 overflow-y-auto pr-2">
                         {project.steps.length === 0 && <p className="text-slate-500 text-sm">No steps added yet.</p>}
                        {project.steps.map(s => <div key={s.id} className="flex items-center gap-2 bg-slate-800 p-2 rounded">
                            <input type="checkbox" checked={s.isCompleted} onChange={() => toggleStep(s.id)} className="h-5 w-5 rounded bg-slate-700 text-rose-500 focus:ring-rose-500 border-slate-600" />
                            <span className={s.isCompleted ? 'line-through text-slate-500' : ''}>{s.description}</span>
                            <button onClick={() => deleteStep(s.id)} className="text-xs text-slate-500 hover:text-white ml-auto">X</button>
                            </div>)}
                    </div>
                     <div className="flex gap-2">
                        <Input label="" placeholder="New step description" value={newStep} onChange={e => setNewStep(e.target.value)} />
                        <Button onClick={addStep} className="mt-auto h-10">Add</Button>
                    </div>
                </Card>
            </div>
            
            <Card>
                <h3 className="text-xl font-bold text-rose-400 mb-4">Cut List</h3>
                <form onSubmit={addCutListItem} className="p-4 bg-slate-800 border border-slate-700 rounded-lg mb-6">
                    <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
                        <div className="col-span-2 lg:col-span-5"><Input label="Part Name" name="part" value={newCutListItem.part} onChange={(e) => setNewCutListItem(p => ({...p, part: e.target.value}))}/></div>
                        <Input label={`Length (${unitLabel})`} name="length" type="number" value={newCutListItem.length} onChange={(e) => setNewCutListItem(p => ({...p, length: e.target.value}))}/>
                        <Input label={`Width (${unitLabel})`} name="width" type="number" value={newCutListItem.width} onChange={(e) => setNewCutListItem(p => ({...p, width: e.target.value}))}/>
                        <Input label={`Thickness (${unitLabel})`} name="thickness" type="number" value={newCutListItem.thickness} onChange={(e) => setNewCutListItem(p => ({...p, thickness: e.target.value}))}/>
                        <Input label="Quantity" name="quantity" type="number" min="1" value={newCutListItem.quantity} onChange={(e) => setNewCutListItem(p => ({...p, quantity: Number(e.target.value)}))}/>
                        <div className="col-span-2 lg:col-span-5"><Button type="submit" variant="primary" className="w-full">Add to List</Button></div>
                    </div>
                </form>
                 <div className="overflow-x-auto bg-slate-900/50 rounded-lg border border-slate-700/50">
                    <table className="min-w-full divide-y divide-slate-700">
                      <thead className="bg-slate-800">
                        <tr>{['Part', 'Qty', `L (${unitLabel})`, `W (${unitLabel})`, `T (${unitLabel})`, 'Actions'].map(h => <th key={h} className="px-6 py-3 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">{h}</th>)}</tr>
                      </thead>
                      <tbody className="bg-slate-800/50 divide-y divide-slate-700">
                        {project.cutListItems.length === 0 && <tr><td colSpan={6} className="text-center py-4 text-slate-500">No cut list items yet.</td></tr>}
                        {project.cutListItems.map(item => (
                          <tr key={item.id}>
                            <td className="px-6 py-4 text-sm font-medium text-slate-200">{item.part}</td>
                            <td className="px-6 py-4 text-sm text-slate-300">{item.quantity}</td>
                            <td className="px-6 py-4 text-sm text-slate-300">{item.length}</td>
                            <td className="px-6 py-4 text-sm text-slate-300">{item.width}</td>
                            <td className="px-6 py-4 text-sm text-slate-300">{item.thickness}</td>
                            <td className="px-6 py-4"><button onClick={() => deleteCutListItem(item.id)} className="text-rose-500 hover:text-rose-400">Delete</button></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};

const AiProjectModal: React.FC<{isOpen: boolean, onClose: () => void, onProjectCreated: (scaffold: ProjectScaffold) => void}> = ({isOpen, onClose, onProjectCreated}) => {
    const [description, setDescription] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const { addToast } = useToast();

    const handleSubmit = async () => {
        if (!description.trim()) {
            addToast('Please describe your project.', 'error');
            return;
        }
        setIsLoading(true);
        try {
            const scaffold = await generateProjectScaffold(description);
            onProjectCreated(scaffold);
            addToast('AI project plan created!', 'success');
            setDescription('');
            onClose();
        } catch (err: any) {
            addToast(err.message || 'Failed to create project with AI.', 'error');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Create Project with AI">
            <div className="space-y-4">
                <p className="text-slate-400">Describe the project you want to build, and the AI will create a starting plan for you.</p>
                <Input 
                    label="Project Description"
                    id="ai-project-desc"
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                    placeholder="e.g., A simple bookshelf made of pine"
                />
                <div className="flex justify-end gap-2">
                    <Button variant="secondary" onClick={onClose} disabled={isLoading}>Cancel</Button>
                    <Button onClick={handleSubmit} disabled={isLoading}>
                        {isLoading ? <LoadingSpinner /> : 'Generate Plan'}
                    </Button>
                </div>
            </div>
        </Modal>
    );
};


export default ProjectPlanner;