import React, { useState, useCallback, useEffect } from 'react';
import { getWoodworkingTip } from '../services/geminiService.ts';
import Card from './common/Card.tsx';
import Button from './common/Button.tsx';
import LoadingSpinner from './common/LoadingSpinner.tsx';
import { ICONS } from '../constants.tsx';

const WoodworkingTips: React.FC = () => {
  const [tip, setTip] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTip = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const newTip = await getWoodworkingTip();
      setTip(newTip);
    } catch (err) {
      setError('Could not fetch a new tip. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTip();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Card className="flex flex-col items-center justify-center text-center">
        <div className="w-16 h-16 bg-rose-900/50 rounded-full flex items-center justify-center mb-4 border border-rose-800">
             <div className="text-rose-400">
                {React.cloneElement(ICONS.TIPS, { className: "h-8 w-8" })}
             </div>
        </div>
        <h2 className="text-2xl font-bold text-slate-100 mb-4">AI Woodworking Tip</h2>
        
        <div className="min-h-[120px] flex items-center justify-center w-full">
            {isLoading ? (
            <LoadingSpinner />
            ) : error ? (
            <p className="text-red-400">{error}</p>
            ) : (
            <blockquote className="text-lg text-slate-300 italic border-l-4 border-rose-500 pl-4">
                {tip}
            </blockquote>
            )}
        </div>

        <Button onClick={fetchTip} disabled={isLoading} className="mt-6">
            {isLoading ? 'Getting Tip...' : 'Get Another Tip'}
        </Button>
    </Card>
  );
};

export default WoodworkingTips;