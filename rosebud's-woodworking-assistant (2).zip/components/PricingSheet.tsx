import React, { useState, useMemo } from 'react';
import Card from './common/Card.tsx';
import Button from './common/Button.tsx';
import { useSettings } from '../contexts/SettingsContext.tsx';
import { CURRENCY_SYMBOLS } from '../types.ts';

const PricingSheet: React.FC = () => {
  const { currency } = useSettings();
  const currencySymbol = CURRENCY_SYMBOLS[currency];
  
  const [materials, setMaterials] = useState('');
  const [laborHours, setLaborHours] = useState('');
  const [laborRate, setLaborRate] = useState('');
  const [overhead, setOverhead] = useState('');
  const [markupPercent, setMarkupPercent] = useState('20');
  const [companyName, setCompanyName] = useState("Rosebud's Woodworking Assistant");

  const { laborCost, subtotal, markupAmount, finalPrice, isValid } = useMemo(() => {
    const matNum = parseFloat(materials) || 0;
    const hoursNum = parseFloat(laborHours) || 0;
    const rateNum = parseFloat(laborRate) || 0;
    const overheadNum = parseFloat(overhead) || 0;
    const markupNum = parseFloat(markupPercent) || 0;

    const currentLaborCost = hoursNum * rateNum;
    const currentSubtotal = matNum + currentLaborCost + overheadNum;
    const currentMarkupAmount = currentSubtotal * (markupNum / 100);
    const currentFinalPrice = currentSubtotal + currentMarkupAmount;

    return {
      laborCost: currentLaborCost,
      subtotal: currentSubtotal,
      markupAmount: currentMarkupAmount,
      finalPrice: currentFinalPrice,
      isValid: matNum > 0 || currentLaborCost > 0,
    };
  }, [materials, laborHours, laborRate, overhead, markupPercent]);
  
  const handlePrint = () => {
    window.print();
  };
  
  const formatCurrency = (amount: number) => {
      return amount.toFixed(2);
  }

  return (
    <Card>
      <div className="flex justify-between items-start mb-6 print:hidden">
        <div>
          <h2 className="text-2xl font-bold text-slate-100 mb-1">Project Pricing Worksheet</h2>
          <p className="text-slate-400">A simple guide to help you price your woodworking projects accurately. Fill it out and print.</p>
        </div>
        <Button onClick={handlePrint} variant="secondary">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H7a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm7-8a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
          Print
        </Button>
      </div>

      <div className="bg-slate-800 p-6 sm:p-8 rounded-lg border border-slate-700 print:bg-white print:text-black print:shadow-none print:p-0">
        <style>
          {`
            @media print {
              body {
                background-color: white !important;
              }
              .printable-area {
                 color: black !important;
              }
              .printable-area h3, .printable-area th, .printable-area td, .printable-area .font-bold {
                color: black !important;
                border-color: #ccc !important;
              }
              .printable-area input {
                  border: 1px solid #ccc !important;
                  color: black !important;
                  background-color: #f9f9f9 !important;
              }
               .printable-area .read-only-val {
                  background-color: #eee !important;
               }
              .printable-area input[type=text]:focus, .printable-area input[type=number]:focus {
                  outline: none !important;
                  border-color: black !important;
              }
              .printable-area .text-rose-400 {
                  color: black !important;
              }
            }
          `}
        </style>
        <div className="printable-area text-slate-300">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-slate-100 print:text-black">Project Pricing Worksheet</h2>
            <p className="text-slate-400 print:text-gray-600">{companyName}</p>
          </div>

          <div className="mb-4">
            <h3 className="text-xl font-semibold text-rose-400 border-b border-slate-600 print:border-gray-300 pb-2 mb-2">Project Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-1"><label className="block">Project Name: <input type="text" className="w-full bg-slate-900 border border-slate-600 rounded p-1 mt-1"/></label></div>
              <div className="md:col-span-1"><label className="block">Client Name: <input type="text" className="w-full bg-slate-900 border border-slate-600 rounded p-1 mt-1"/></label></div>
              <div className="md:col-span-2"><label className="block">Company Name: <input type="text" value={companyName} onChange={e => setCompanyName(e.target.value)} className="w-full bg-slate-900 border border-slate-600 rounded p-1 mt-1"/></label></div>
            </div>
          </div>
          
          <table className="w-full text-left border-collapse mt-4">
            <thead>
              <tr>
                <th className="border-b-2 border-slate-600 p-2 w-1/3">Item</th>
                <th className="border-b-2 border-slate-600 p-2">Details / Calculation</th>
                <th className="border-b-2 border-slate-600 p-2 text-right w-1/4">Cost</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-slate-700">
                <td className="p-2 font-semibold">1. Materials Cost</td>
                <td className="p-2"><input type="text" placeholder="Wood, screws, glue, finish..." className="w-full bg-slate-900 border border-slate-600 rounded p-1"/></td>
                <td className="p-2 text-right">{currencySymbol} <input type="number" placeholder="0.00" value={materials} onChange={e => setMaterials(e.target.value)} className="w-24 text-right bg-slate-900 border border-slate-600 rounded p-1"/></td>
              </tr>
              <tr className="border-b border-slate-700">
                <td className="p-2 font-semibold">2. Labor Cost</td>
                <td className="p-2">
                    <input type="number" placeholder="hours" value={laborHours} onChange={e => setLaborHours(e.target.value)} className="w-20 bg-slate-900 border border-slate-600 rounded p-1 mr-1"/>
                    x {currencySymbol}
                    <input type="number" placeholder="rate/hr" value={laborRate} onChange={e => setLaborRate(e.target.value)} className="w-20 bg-slate-900 border border-slate-600 rounded p-1 ml-1"/>
                </td>
                <td className="p-2 text-right">{currencySymbol} <input type="text" readOnly value={formatCurrency(laborCost)} className="w-24 text-right bg-slate-900 border border-slate-600 rounded p-1 read-only-val"/></td>
              </tr>
               <tr className="border-b border-slate-700">
                <td className="p-2 font-semibold">3. Overhead / Shop Costs</td>
                <td className="p-2"><input type="text" placeholder="Electricity, blades, sandpaper..." className="w-full bg-slate-900 border border-slate-600 rounded p-1"/></td>
                <td className="p-2 text-right">{currencySymbol} <input type="number" placeholder="0.00" value={overhead} onChange={e => setOverhead(e.target.value)} className="w-24 text-right bg-slate-900 border border-slate-600 rounded p-1"/></td>
              </tr>
              <tr className="border-b-2 border-slate-700">
                <td className="p-2 font-bold">Subtotal</td>
                <td className="p-2"></td>
                <td className="p-2 text-right font-bold">{currencySymbol} <input type="text" readOnly value={formatCurrency(subtotal)} className="w-24 text-right bg-slate-900 border border-slate-600 rounded p-1 font-bold read-only-val"/></td>
              </tr>
              <tr className="border-b border-slate-700">
                <td className="p-2 font-semibold">Markup / Profit Margin</td>
                <td className="p-2"><input type="number" placeholder="e.g., 20" value={markupPercent} onChange={e => setMarkupPercent(e.target.value)} className="w-20 bg-slate-900 border border-slate-600 rounded p-1 mr-1"/> %</td>
                <td className="p-2 text-right">{currencySymbol} <input type="text" readOnly value={formatCurrency(markupAmount)} className="w-24 text-right bg-slate-900 border border-slate-600 rounded p-1 read-only-val"/></td>
              </tr>
            </tbody>
            <tfoot>
               <tr>
                <td className="p-2 pt-4 text-xl font-bold text-rose-400" colSpan={2}>Final Price</td>
                <td className="p-2 pt-4 text-xl text-right font-bold text-rose-400">{currencySymbol} <input readOnly type="text" value={formatCurrency(finalPrice)} className="w-28 text-right bg-transparent border-none p-1 font-bold text-rose-400 text-xl"/></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </Card>
  );
};

export default PricingSheet;