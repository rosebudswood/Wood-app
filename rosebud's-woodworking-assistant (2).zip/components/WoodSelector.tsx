import React, { useState, useCallback } from 'react';
import { getWoodSuggestions } from '../services/geminiService.ts';
import { WoodSuggestion, Region, REGIONS } from '../types.ts';
import Card from './common/Card.tsx';
import Input from './common/Input.tsx';
import Button from './common/Button.tsx';
import LoadingSpinner from './common/LoadingSpinner.tsx';

const WoodSelector: React.FC = () => {
  const [project, setProject] = useState('');
  const [region, setRegion] = useState<Region>('North America');
  const [suggestions, setSuggestions] = useState<WoodSuggestion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchSuggestions = useCallback(async () => {
    if (!project) {
      setError('Please describe your project.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setSuggestions([]);
    try {
      const result = await getWoodSuggestions(project, region);
      setSuggestions(result);
    } catch (err) {
      setError('Sorry, I had trouble getting suggestions. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [project, region]);

  const SuggestionCard: React.FC<{ suggestion: WoodSuggestion }> = ({ suggestion }) => (
    <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700/50">
        <h3 className="text-lg font-bold text-rose-400">{suggestion.wood}</h3>
        <p className="text-slate-400 mt-1 mb-3 text-sm">{suggestion.reason}</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <h4 className="font-semibold text-green-400">Pros</h4>
                <ul className="list-disc list-inside text-sm text-slate-300 space-y-1">
                    {suggestion.pros.map((pro, i) => <li key={i}>{pro}</li>)}
                </ul>
            </div>
            <div>
                <h4 className="font-semibold text-red-400">Cons</h4>
                <ul className="list-disc list-inside text-sm text-slate-300 space-y-1">
                    {suggestion.cons.map((con, i) => <li key={i}>{con}</li>)}
                </ul>
            </div>
        </div>
    </div>
  );

  return (
    <Card>
      <h2 className="text-2xl font-bold text-slate-100 mb-1">AI Wood Selector</h2>
      <p className="text-slate-400 mb-6">Describe your project, specify your region, and I'll suggest the best types of wood to use.</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="sm:col-span-2">
          <Input
            label="What are you building?"
            id="project-description"
            value={project}
            onChange={(e) => setProject(e.target.value)}
            placeholder="e.g., An outdoor dining table"
          />
        </div>
        <div>
            <label htmlFor="region-selector" className="block text-sm font-medium text-slate-400 mb-1">
                Your Region
            </label>
            <select
            id="region-selector"
            value={region}
            onChange={(e) => setRegion(e.target.value as Region)}
            className="block w-full h-10 px-3 py-2 bg-slate-900 border border-slate-600 rounded-md shadow-sm focus:outline-none focus:ring-rose-500 focus:border-rose-500 sm:text-sm text-white"
            >
            {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
        </div>
      </div>

      <div className="mt-4">
        <Button onClick={fetchSuggestions} disabled={isLoading} className="w-full">
            {isLoading ? 'Thinking...' : 'Get Suggestions'}
        </Button>
      </div>


      {error && <p className="text-red-400 mt-4 text-center">{error}</p>}
      
      <div className="mt-8">
        {isLoading && <LoadingSpinner />}
        {suggestions.length > 0 && (
          <div className="space-y-4">
            {suggestions.map((s, i) => <SuggestionCard key={i} suggestion={s} />)}
          </div>
        )}
      </div>
    </Card>
  );
};

export default WoodSelector;