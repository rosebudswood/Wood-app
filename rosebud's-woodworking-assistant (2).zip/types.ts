export enum View {
  DASHBOARD = 'DASHBOARD',
  TIPS = 'TIPS',
  GETTING_STARTED = 'GETTING_STARTED',
  WOOD_SELECTOR = 'WOOD_SELECTOR',
  FINISHING_GUIDE = 'FINISHING_GUIDE',
  CUT_LIST = 'CUT_LIST',
  ARC_CALCULATOR = 'ARC_CALCULATOR',
  LUMBER_VOLUME_CALCULATOR = 'LUMBER_VOLUME_CALCULATOR',
  PRICING_GUIDE = 'PRICING_GUIDE',
  TOOL_INVENTORY = 'TOOL_INVENTORY',
  PROJECT_PLANNER = 'PROJECT_PLANNER',
  AI_CHAT = 'AI_CHAT',
}

export type UnitSystem = 'imperial' | 'metric';
export type Currency = 'USD' | 'GBP' | 'EUR';
export type Region = 'North America' | 'UK & Europe' | 'Australia & NZ' | 'Asia' | 'Other';

export const REGIONS: Region[] = ['North America', 'UK & Europe', 'Australia & NZ', 'Asia', 'Other'];

export const CURRENCY_SYMBOLS: Record<Currency, string> = {
  USD: '$',
  GBP: '£',
  EUR: '€',
};

export interface CutListItem {
  id: number;
  part: string;
  length: string;
  width: string;
  thickness: string;
  quantity: number;
}

export interface WoodSuggestion {
  wood: string;
  reason: string;
  pros: string[];
  cons: string[];
}

export interface FinishSuggestion {
  finish: string;
  type: string;
  reason: string;
  pros: string[];
  cons: string[];
  application: string;
}

export interface GettingStartedStep {
    title: string;
    description: string;
}

export interface EssentialTool {
    tool: string;
    type: string;
    description: string;
}

export interface GettingStartedContent {
    firstSteps: GettingStartedStep[];
    essentialTools: EssentialTool[];
}

export interface Tool {
  id: number;
  name: string;
  category: string;
  brand: string;
  notes: string;
}

export interface ProjectStep {
  id: number;
  description: string;
  isCompleted: boolean;
}

export interface ProjectMaterial {
  id: number;
  item: string;
  quantity: string;
}

export interface Project {
  id: number;
  name: string;
  description: string;
  status: 'Planning' | 'In Progress' | 'Completed';
  cutListItems: CutListItem[];
  steps: ProjectStep[];
  materials: ProjectMaterial[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface ProjectScaffold {
    name: string;
    description: string;
    materials: { item: string, quantity: string }[];
    steps: string[];
}