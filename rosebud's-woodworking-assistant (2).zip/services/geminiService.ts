import { GoogleGenAI, GenerateContentResponse, Chat } from "@google/genai";
import { WoodSuggestion, FinishSuggestion, GettingStartedContent, Region, ProjectScaffold } from '../types.ts';

// This is a browser environment, so `process.env.API_KEY` will not be available
// unless it's injected by a build tool. We check for it safely to avoid crashing the app.
const API_KEY = (globalThis as any).process?.env?.API_KEY;

let ai: GoogleGenAI | null = null;
if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
} else {
  console.warn(
    "Google AI API key not found. AI features will be disabled. " +
    "Please set the API_KEY environment variable if you want to use AI features."
  );
}

const checkAiInitialized = () => {
    if (!ai) {
        // This error will be caught by the calling components and displayed to the user.
        throw new Error("AI service is not configured. An API key is required.");
    }
    return ai;
}

/**
 * A highly-resilient function to extract and parse JSON from a potentially noisy string.
 * It tries multiple strategies to find valid JSON.
 * @param text The raw text response from the AI.
 * @returns An array of parsed JSON objects, or throws an error if nothing can be found.
 */
function extractAndParseJson(text: string): any[] {
    // Strategy 1: Find a JSON markdown block and parse it. This is the most reliable.
    const fenceMatch = text.match(/```json\s*([\s\S]*?)\s*```/);
    if (fenceMatch && fenceMatch[1]) {
        try {
            const parsed = JSON.parse(fenceMatch[1]);
            // Ensure the result is always an array.
            return Array.isArray(parsed) ? parsed : [parsed];
        } catch (e) {
            console.warn("Found a JSON code fence, but its content was not valid JSON.", e);
            // Fall through to other strategies...
        }
    }

    // Strategy 2: Extract content between the first '{' or '[' and the last '}' or ']'.
    // This handles cases where there's junk text before or after a single JSON object/array.
    const firstBracket = text.indexOf('[');
    const lastBracket = text.lastIndexOf(']');
    const firstBrace = text.indexOf('{');
    const lastBrace = text.lastIndexOf('}');

    // Prioritize array if it appears to be the container
    if (firstBracket !== -1 && lastBracket > firstBracket) {
         if (firstBracket < firstBrace || firstBrace === -1) {
            const potentialJson = text.substring(firstBracket, lastBracket + 1);
            try {
                const parsed = JSON.parse(potentialJson);
                return Array.isArray(parsed) ? parsed : [parsed];
            } catch (e) {
                // Not a valid JSON array, fall through
            }
         }
    }
    
    // Try for an object if it's the primary container or array parsing failed
    if (firstBrace !== -1 && lastBrace > firstBrace) {
        const potentialJson = text.substring(firstBrace, lastBrace + 1);
        try {
            const parsed = JSON.parse(potentialJson);
            return Array.isArray(parsed) ? parsed : [parsed];
        } catch (e) {
            // Not a valid JSON object, fall through
        }
    }

    // Strategy 3: Manually extract all brace-balanced objects.
    // This is a robust fallback for very messy responses with multiple JSON objects.
    const objects = [];
    let braceCount = 0;
    let startIndex = -1;
    for (let i = 0; i < text.length; i++) {
        if (text[i] === '{') {
            if (braceCount === 0) startIndex = i;
            braceCount++;
        } else if (text[i] === '}') {
            if (braceCount > 0) {
                braceCount--;
                if (braceCount === 0 && startIndex !== -1) {
                    const objString = text.substring(startIndex, i + 1);
                    try {
                        objects.push(JSON.parse(objString));
                    } catch (e) {
                       // Ignore malformed fragments
                    }
                }
            }
        }
    }

    if (objects.length > 0) {
        return objects;
    }
    
    // If all strategies fail, throw an error.
    console.error("Failed to parse or find any JSON objects in the response.", { originalText: text });
    throw new Error("Response was not in a recognizable JSON format.");
}


export async function getWoodworkingTip(): Promise<string> {
  const ai = checkAiInitialized();
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: "Give me a useful, concise woodworking tip. Focus on something a beginner to intermediate woodworker would find helpful.",
    });
    return response.text;
  } catch (error) {
    console.error("Error fetching woodworking tip:", error);
    throw new Error("Failed to fetch tip from Gemini API.");
  }
}

export async function getWoodSuggestions(projectDescription: string, region: Region): Promise<WoodSuggestion[]> {
  const ai = checkAiInitialized();
  const prompt = `
    As an expert woodworker, I need project advice. I am located in the **${region}** region.
    Please suggest 3 different types of wood suitable for my project: "${projectDescription}".

    **CRITICAL:** Your suggestions MUST prioritize woods that are commonly available, accessible, and reasonably priced in the **${region}** region. For example, if the region is 'UK & Europe', you should suggest woods like Beech or European Oak over something like American Black Walnut or Hard Maple unless they are also common there. Your answer needs to be practical for the user's location.

    For each suggestion, provide the following information in a JSON array format. Do not include any text outside of the JSON array.
    The JSON schema for each object in the array should be:
    {
      "wood": "Name of the wood",
      "reason": "A brief sentence explaining why it's a good choice for this project, considering the region.",
      "pros": ["A few key advantages as an array of strings"],
      "cons": ["A few key disadvantages as an array of strings"]
    }
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });
    
    const parsedData = extractAndParseJson(response.text) as WoodSuggestion[];

    if (Array.isArray(parsedData) && parsedData.length > 0 && parsedData.every(item => item && typeof item === 'object' && 'wood' in item && 'reason' in item)) {
        return parsedData;
    } else {
        console.error("Parsed data from Gemini is not in the expected WoodSuggestion[] format:", parsedData);
        throw new Error("AI response format is incorrect.");
    }

  } catch (error) {
    console.error("Error fetching wood suggestions:", error);
    if (error instanceof Error && error.message.includes("recognizable JSON format")) {
        throw error;
    }
    throw new Error("Failed to fetch wood suggestions from Gemini API.");
  }
}

export async function getFinishSuggestions(projectDescription: string): Promise<FinishSuggestion[]> {
  const ai = checkAiInitialized();
  const prompt = `
    I need to choose a finish for a woodworking project. Please suggest 3 different types of wood finish suitable for: "${projectDescription}".

    For each suggestion, provide the following information in a JSON array format. Do not include any text outside of the JSON array.
    The JSON schema for each object in the array should be:
    {
      "finish": "Name of the finish (e.g., Tung Oil, Polyurethane)",
      "type": "The general category (e.g., 'Oil-based Varnish', 'Water-based Polyurethane', 'Hardwax-Oil')",
      "reason": "A brief sentence explaining why it's a good choice for this project.",
      "pros": ["A few key advantages as an array of strings"],
      "cons": ["A few key disadvantages as an array of strings"],
      "application": "Brief summary of how to apply it."
    }
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const parsedData = extractAndParseJson(response.text) as FinishSuggestion[];

     if (Array.isArray(parsedData) && parsedData.length > 0 && parsedData.every(item => item && typeof item === 'object' && 'finish' in item && 'reason' in item)) {
        return parsedData;
    } else {
        console.error("Parsed data from Gemini is not in the expected FinishSuggestion[] format:", parsedData);
        throw new Error("AI response format is incorrect.");
    }

  } catch (error) {
    console.error("Error fetching finish suggestions:", error);
    if (error instanceof Error && error.message.includes("recognizable JSON format")) {
        throw error;
    }
    throw new Error("Failed to fetch finish suggestions from Gemini API.");
  }
}

export async function getGettingStartedContent(): Promise<GettingStartedContent> {
  const ai = checkAiInitialized();
  const prompt = `
    Provide a comprehensive "getting started" guide for an absolute beginner woodworker. The tone should be encouraging, clear, and structured.
    Return the response as a single JSON object. Do not include any text outside of the JSON object.
    The JSON schema should be:
    {
      "firstSteps": [
        {
          "title": "Step Title",
          "description": "A detailed but easy-to-understand paragraph explaining the step. Start with an action verb and explain the 'why' behind the step."
        }
      ],
      "essentialTools": [
        {
          "tool": "Tool Name",
          "type": "Category (e.g., 'Safety Gear', 'Measurement & Marking', 'Hand Tools', 'Power Tools')",
          "description": "Explain what this tool is used for, why it's essential, and provide a tip for a beginner buying or using it."
        }
      ]
    }

    Please provide 4-5 detailed "firstSteps".
    For "essentialTools", provide a list of 8-10 tools, making sure to include these categories and specific tools:
    - **Safety Gear**: At least safety glasses and dust mask.
    - **Measurement & Marking**: At least a tape measure and a combination square.
    - **Hand Tools**: At least a handsaw and a set of chisels.
    - **Power Tools**: Specifically include a Cordless Drill, a Jigsaw, and an Orbital Sander. Explain why these are great starter power tools.
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-04-17",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const parsedArray = extractAndParseJson(response.text);
    if (!parsedArray || parsedArray.length === 0) {
      throw new Error("AI response was empty or did not contain a valid object.");
    }
    const parsedData = parsedArray[0] as GettingStartedContent;

    if (parsedData && typeof parsedData === 'object' && Array.isArray(parsedData.firstSteps) && Array.isArray(parsedData.essentialTools)) {
        return parsedData;
    } else {
        console.error("Parsed data from Gemini is not in the expected GettingStartedContent format:", parsedData);
        throw new Error("AI response format is incorrect.");
    }

  } catch (error) {
    console.error("Error fetching getting started content:", error);
    if (error instanceof Error && error.message.includes("recognizable JSON format")) {
        throw error;
    }
    throw new Error("Failed to fetch getting started content from Gemini API.");
  }
}

export function createChatSession(): Chat {
    const ai = checkAiInitialized();
    return ai.chats.create({
        model: 'gemini-2.5-flash-preview-04-17',
        config: {
          systemInstruction: 'You are an expert woodworking assistant. You provide clear, concise, and safe advice. You are friendly and encouraging to woodworkers of all skill levels.',
        },
    });
}

export async function generateProjectScaffold(description: string): Promise<ProjectScaffold> {
    const ai = checkAiInitialized();
    const prompt = `
        Based on the user's project description, generate a starter project plan.
        Project Description: "${description}"

        Your response must be a single JSON object. Do not include any text outside of the JSON object.
        The JSON schema should be:
        {
          "name": "A concise and appropriate name for the project",
          "description": "A one-sentence description of the project, based on the user's input.",
          "materials": [
            { "item": "Material Name (e.g., 'Pine 1x4 boards')", "quantity": "e.g., '4x 8ft'" },
            { "item": "Wood glue", "quantity": "1 bottle" },
            { "item": "2-inch wood screws", "quantity": "1 box" }
          ],
          "steps": [
            "First step of the project.",
            "Second step of the project.",
            "Third step...",
            "Final finishing step."
          ]
        }

        Generate a reasonable plan with 3-5 materials and 5-8 high-level steps.
    `;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
            },
        });

        const parsedArray = extractAndParseJson(response.text);
        if (!parsedArray || parsedArray.length === 0) {
            throw new Error("AI response was empty or did not contain a valid object.");
        }
        const parsedData = parsedArray[0] as ProjectScaffold;

        if (parsedData && parsedData.name && parsedData.materials && parsedData.steps) {
            return parsedData;
        } else {
            console.error("Parsed data from Gemini is not in the expected ProjectScaffold format:", parsedData);
            throw new Error("AI response format is incorrect.");
        }

    } catch (error) {
        console.error("Error generating project scaffold:", error);
        if (error instanceof Error && error.message.includes("recognizable JSON format")) {
            throw error;
        }
        throw new Error("Failed to generate project plan from Gemini API.");
    }
}