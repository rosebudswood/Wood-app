import React, { useState } from 'react';
import Header from './components/Header.tsx';
import Navigation from './components/Navigation.tsx';
import WoodworkingTips from './components/WoodworkingTips.tsx';
import WoodSelector from './components/WoodSelector.tsx';
import CutList from './components/CutList.tsx';
import ArcCalculator from './components/ArcCalculator.tsx';
import FinishingGuide from './components/FinishingGuide.tsx';
import LumberVolumeCalculator from './components/LumberVolumeCalculator.tsx';
import GettingStarted from './components/GettingStarted.tsx';
import PricingSheet from './components/PricingSheet.tsx';
import Dashboard from './components/Dashboard.tsx';
import ToolInventory from './components/ToolInventory.tsx';
import ProjectPlanner from './components/ProjectPlanner.tsx';
import AiChat from './components/AiChat.tsx';
import ToastContainer from './components/common/Toast.tsx';
import { View } from './types.ts';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<View>(View.DASHBOARD);
  
  const renderActiveView = () => {
    switch (activeView) {
      case View.DASHBOARD:
        return <Dashboard setActiveView={setActiveView} />;
      case View.TIPS:
        return <WoodworkingTips />;
      case View.GETTING_STARTED:
        return <GettingStarted />;
      case View.WOOD_SELECTOR:
        return <WoodSelector />;
      case View.FINISHING_GUIDE:
        return <FinishingGuide />;
      case View.CUT_LIST:
        return <CutList />;
      case View.ARC_CALCULATOR:
        return <ArcCalculator />;
      case View.LUMBER_VOLUME_CALCULATOR:
        return <LumberVolumeCalculator />;
      case View.PRICING_GUIDE:
        return <PricingSheet />;
      case View.TOOL_INVENTORY:
        return <ToolInventory />;
      case View.PROJECT_PLANNER:
        return <ProjectPlanner />;
      case View.AI_CHAT:
        return <AiChat />;
      default:
        return <Dashboard setActiveView={setActiveView} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-300 font-sans">
      <ToastContainer />
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1 print:hidden">
            <Navigation activeView={activeView} setActiveView={setActiveView} />
          </div>
          <div className="md:col-span-3">
            {renderActiveView()}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;