const CACHE_NAME = 'rosebud-woodworking-assistant-v5'; // Updated cache name
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
  '/privacy-policy.html',
  '/.well-known/assetlinks.json',
  '/favicon.svg',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  
  // Scripts
  '/index.tsx',
  '/App.tsx',
  '/types.ts',
  '/constants.tsx',
  '/hooks/useLocalStorage.ts',
  '/services/geminiService.ts',
  '/contexts/SettingsContext.tsx',
  '/contexts/ToastContext.tsx',

  // Components
  '/components/AiChat.tsx',
  '/components/ArcCalculator.tsx',
  '/components/CutList.tsx',
  '/components/Dashboard.tsx',
  '/components/FinishingGuide.tsx',
  '/components/GettingStarted.tsx',
  '/components/Header.tsx',
  '/components/LumberVolumeCalculator.tsx',
  '/components/Navigation.tsx',
  '/components/PricingSheet.tsx',
  '/components/ProjectPlanner.tsx',
  '/components/ToolInventory.tsx',
  '/components/WoodSelector.tsx',
  '/components/WoodworkingTips.tsx',
  
  // Common Components
  '/components/common/Button.tsx',
  '/components/common/Card.tsx',
  '/components/common/Input.tsx',
  '/components/common/LoadingSpinner.tsx',
  '/components/common/Modal.tsx',
  '/components/common/Toast.tsx',

  // External Libs
  'https://cdn.tailwindcss.com',
  'https://esm.sh/react@^19.1.0',
  'https://esm.sh/react-dom@^19.1.0/client',
  'https://esm.sh/@google/genai@^1.8.0'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        // Use addAll with a catch to prevent install failure if one asset fails
        return cache.addAll(urlsToCache).catch(err => {
          console.error('Failed to cache files during install:', err);
        });
      })
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - return response
        if (response) {
          return response;
        }

        // Clone the request because it's a stream and can only be consumed once.
        const fetchRequest = event.request.clone();

        return fetch(fetchRequest).then(
          response => {
            // Check if we received a valid response
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }
            
            // Clone the response because it's also a stream.
            const responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then(cache => {
                // We don't cache API requests to Gemini
                if (!event.request.url.includes('generativelanguage')) {
                    cache.put(event.request, responseToCache);
                }
              });

            return response;
          }
        );
      })
    );
});

self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});